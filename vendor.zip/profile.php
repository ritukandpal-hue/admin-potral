<?php
// ============================================================
// FILE PATH ON HOSTINGER: public_html/vendor/profile.php
// ============================================================
declare(strict_types=1);
$configs=[dirname(__DIR__,2).'/config.php',dirname(__DIR__,1).'/config.php',
    '/home/u624259711/domains/orchid-alligator-169347.hostingersite.com/config.php'];
foreach($configs as $c){if(file_exists($c)){require_once $c;break;}}
if(!defined('PUBLIC_PATH')) die('<p style="color:red;padding:40px">config.php not found</p>');
require_once PUBLIC_PATH.'/includes/db.php';
require_once PUBLIC_PATH.'/includes/auth.php';
require_once PUBLIC_PATH.'/includes/functions.php';
startSession(); requireLogin('vendor');
$user=currentUser(); $db=getDB();
$vendor_stmt=$db->prepare("SELECT * FROM vendors WHERE user_id=?");
$vendor_stmt->execute([$user['id']]); $vendor=$vendor_stmt->fetch();
if(!$vendor) die('<p style="color:red;padding:40px">Vendor not found.</p>');
$vid=$vendor['id'];
$msg=$error='';

if($_SERVER['REQUEST_METHOD']==='POST' && verifyCsrf()){
    if(isset($_POST['update_profile'])){
        $contact_name  = clean($_POST['contact_name']??'');
        $contact_phone = clean($_POST['contact_phone']??'');
        $contact_email = clean($_POST['contact_email']??'');
        $address       = clean($_POST['address']??'');
        $city          = clean($_POST['city']??'');
        $state         = clean($_POST['state']??'');
        $pin           = clean($_POST['pin']??'');
        $bank_account  = clean($_POST['bank_account']??'');
        $bank_ifsc     = clean($_POST['bank_ifsc']??'');
        $bank_name     = clean($_POST['bank_name']??'');
        $bank_acc_name = clean($_POST['bank_account_name']??'');

        $db->prepare("UPDATE vendors SET contact_name=?,contact_phone=?,contact_email=?,
            address=?,city=?,state=?,pin=?,bank_account=?,bank_ifsc=?,bank_name=?,
            bank_account_name=?,updated_at=NOW() WHERE id=?")
           ->execute([$contact_name,$contact_phone,$contact_email,$address,$city,$state,$pin,
               $bank_account,$bank_ifsc,$bank_name,$bank_acc_name,$vid]);

        // Reload vendor
        $vs=$db->prepare("SELECT * FROM vendors WHERE id=?");$vs->execute([$vid]);$vendor=$vs->fetch();
        $msg='Profile updated successfully.';
    }

    if(isset($_POST['change_password'])){
        $old_pw = $_POST['old_password']??'';
        $new_pw = $_POST['new_password']??'';
        $confirm= $_POST['confirm_password']??'';
        if(strlen($new_pw)<8){$error='New password must be at least 8 characters.';}
        elseif($new_pw!==$confirm){$error='Passwords do not match.';}
        else{
            $u=$db->prepare("SELECT password_hash FROM users WHERE id=?");$u->execute([$user['id']]);
            $hash=$u->fetchColumn();
            if(!password_verify($old_pw,$hash)){$error='Current password is incorrect.';}
            else{
                $new_hash=password_hash($new_pw,PASSWORD_BCRYPT,['cost'=>12]);
                $db->prepare("UPDATE users SET password_hash=? WHERE id=?")->execute([$new_hash,$user['id']]);
                $msg='Password changed successfully.';
            }
        }
    }
}
?>

<!DOCTYPE html><html lang="en"><head>

<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">

<title>Profile — Dausto Vendor</title>
<script src="https://cdn.tailwindcss.com"></script>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800;900&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}body{font-family:'DM Sans',sans-serif;background:#F0F2F5;color:#0F172A}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:240px;background:linear-gradient(180deg,#1A1A2E,#16213E);display:flex;flex-direction:column;z-index:100}
.nav-link{display:flex;align-items:center;gap:10px;padding:9px 14px 9px 18px;margin:1px 8px;border-radius:9px;font-size:13.5px;font-weight:600;color:rgba(255,255,255,0.55);text-decoration:none;white-space:nowrap}
.nav-link:hover{background:rgba(255,255,255,0.08);color:#fff}.nav-link.active{background:#D97706;color:#fff}
.nav-group{font-size:9.5px;font-weight:700;color:rgba(255,255,255,0.2);letter-spacing:.12em;padding:12px 22px 4px}
.main{margin-left:240px;min-height:100vh}.topbar{background:#fff;border-bottom:1px solid #E2E8F0;padding:14px 26px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:40}
.card{background:#fff;border-radius:14px;border:1px solid #E8ECF2;box-shadow:0 1px 4px rgba(0,0,0,0.04);overflow:hidden}
.card-head{padding:15px 18px;border-bottom:1px solid #F0F3F6;display:flex;align-items:center;justify-content:space-between}
.card-title{font-size:14px;font-weight:800;color:#0F172A}
.btn{padding:9px 18px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:6px;font-family:'DM Sans',sans-serif}
.btn-primary{background:#D97706;color:#fff}.btn-ghost{background:#F8FAFC;color:#374151;border:1px solid #E2E8F0}
.form-label{display:block;font-size:11px;font-weight:700;color:#374151;letter-spacing:.06em;margin-bottom:5px;text-transform:uppercase}
.form-input{width:100%;border:1.5px solid #E2E8F0;border-radius:9px;padding:10px 13px;font-size:13.5px;color:#0F172A;font-family:'DM Sans',sans-serif;outline:none;background:#FAFBFC}
.form-input:focus{border-color:#D97706;box-shadow:0 0 0 3px rgba(217,119,6,0.15);background:#fff}
.alert{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:16px}
.alert-success{background:#FFFBEB;border:1px solid #FDE68A;color:#92400E}
.alert-error{background:#FEF2F2;border:1px solid #FECACA;color:#7F1D1D}
</style></head><body>
<aside class="sidebar">
  <div style="padding:18px 16px 14px;border-bottom:1px solid rgba(255,255,255,0.07)">
    <div style="display:flex;align-items:center;gap:10px">
      <div style="width:34px;height:34px;background:linear-gradient(135deg,#D97706,#F59E0B);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:16px">🏪</div>
      <div><div style="font-family:'Playfair Display',serif;font-size:14px;font-weight:900;color:#fff;line-height:1;max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=htmlspecialchars($vendor['company_name'])?></div>
      <div style="font-size:9px;color:rgba(255,255,255,0.3);font-weight:700;letter-spacing:.1em">VENDOR PORTAL</div></div>
    </div>
  </div>
  <nav style="flex:1;overflow-y:auto;padding:8px 0">
    <div class="nav-group">MAIN</div>
    <a href="index.php" class="nav-link"><span style="width:22px;text-align:center;font-size:16px">🏠</span> Dashboard</a>
    <a href="orders.php" class="nav-link"><span style="width:22px;text-align:center;font-size:16px">📋</span> My Orders</a>
    <div class="nav-group">CATALOGUE</div>
    <a href="products.php" class="nav-link"><span style="width:22px;text-align:center;font-size:16px">📦</span> My Products</a>
    <a href="inventory.php" class="nav-link"><span style="width:22px;text-align:center;font-size:16px">📊</span> Inventory</a>
    <div class="nav-group">FINANCE</div>
    <a href="earnings.php" class="nav-link"><span style="width:22px;text-align:center;font-size:16px">💰</span> Earnings</a>
    <div class="nav-group">ACCOUNT</div>
    <a href="profile.php" class="nav-link active"><span style="width:22px;text-align:center;font-size:16px">👤</span> Profile</a>
    <a href="../admin/logout.php" class="nav-link" style="color:rgba(255,100,100,0.7)"><span style="width:22px;text-align:center;font-size:16px">⏻</span> Logout</a>
  </nav>
</aside>
<main class="main">
<div class="topbar">
  <div><h1 style="font-size:20px;font-weight:900;font-family:'Playfair Display',serif">My Profile</h1>
  <p style="font-size:12px;color:#94A3B8;margin-top:2px"><?=htmlspecialchars($vendor['company_name'])?> · <?=htmlspecialchars($user['email'])?></p></div>
</div>
<div style="padding:24px">
<?php if($msg): ?><div class="alert alert-success">✅ <?=htmlspecialchars($msg)?></div><?php endif ?>
<?php if($error): ?><div class="alert alert-error">❌ <?=htmlspecialchars($error)?></div><?php endif ?>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">

  <!-- Contact & Address -->

  <div class="card">
    <div class="card-head"><div class="card-title">👤 Contact Information</div></div>
    <div style="padding:18px">
      <form method="POST">
        <?=csrfField()?>
        <input type="hidden" name="update_profile" value="1">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
          <div><label class="form-label">Contact Name</label><input type="text" name="contact_name" class="form-input" value="<?=htmlspecialchars($vendor['contact_name']??'')?>"></div>
          <div><label class="form-label">Phone / WhatsApp</label><input type="text" name="contact_phone" class="form-input" value="<?=htmlspecialchars($vendor['contact_phone']??'')?>"></div>
          <div style="grid-column:span 2"><label class="form-label">Contact Email</label><input type="email" name="contact_email" class="form-input" value="<?=htmlspecialchars($vendor['contact_email']??'')?>"></div>
          <div style="grid-column:span 2"><label class="form-label">Address</label><textarea name="address" class="form-input" style="min-height:70px;resize:vertical"><?=htmlspecialchars($vendor['address']??'')?></textarea></div>
          <div><label class="form-label">City</label><input type="text" name="city" class="form-input" value="<?=htmlspecialchars($vendor['city']??'')?>"></div>
          <div><label class="form-label">State</label><input type="text" name="state" class="form-input" value="<?=htmlspecialchars($vendor['state']??'')?>"></div>
          <div><label class="form-label">PIN Code</label><input type="text" name="pin" class="form-input" value="<?=htmlspecialchars($vendor['pin']??'')?>"></div>
        </div>

```
    <div style="border-top:1px solid #F0F3F6;padding-top:14px;margin-top:4px">
      <div style="font-size:12px;font-weight:700;color:#0F172A;margin-bottom:12px">🏦 Bank Details (for payouts)</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div style="grid-column:span 2"><label class="form-label">Bank Name</label><input type="text" name="bank_name" class="form-input" value="<?=htmlspecialchars($vendor['bank_name']??'')?>"></div>
        <div style="grid-column:span 2"><label class="form-label">Account Holder Name</label><input type="text" name="bank_account_name" class="form-input" value="<?=htmlspecialchars($vendor['bank_account_name']??'')?>"></div>
        <div><label class="form-label">Account Number</label><input type="text" name="bank_account" class="form-input" value="<?=htmlspecialchars($vendor['bank_account']??'')?>"></div>
        <div><label class="form-label">IFSC Code</label><input type="text" name="bank_ifsc" class="form-input" placeholder="HDFC0001234" value="<?=htmlspecialchars($vendor['bank_ifsc']??'')?>"></div>
      </div>
    </div>

    <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:16px">💾 Save Profile</button>
  </form>
</div>
```

  </div>

  <div style="display:flex;flex-direction:column;gap:16px">
    <!-- Company info (read-only) -->
    <div class="card">
      <div class="card-head"><div class="card-title">🏢 Company Info</div><span style="font-size:11px;color:#94A3B8">Contact Dausto to update</span></div>
      <div style="padding:16px 18px;display:flex;flex-direction:column;gap:10px">
        <?php foreach([
          ['Company',$vendor['company_name']],
          ['GSTIN',$vendor['gstin']??'—'],
          ['PAN',$vendor['pan']??'—'],
          ['KYC Status',ucfirst($vendor['kyc_status'])],
          ['Payout Frequency',ucfirst($vendor['payout_frequency'])],
          ['Margin Type',ucfirst(str_replace('_',' ',$vendor['default_margin_type'])).' '.$vendor['default_margin_value'].'%'],
        ] as [$l,$v]): ?>
        <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid #F8FAFC">
          <span style="font-size:12.5px;color:#64748B"><?=$l?></span>
          <span style="font-size:13px;font-weight:700;color:#0F172A"><?=htmlspecialchars($v)?></span>
        </div>
        <?php endforeach ?>
      </div>
    </div>

```
<!-- Change password -->
<div class="card">
  <div class="card-head"><div class="card-title">🔐 Change Password</div></div>
  <div style="padding:16px 18px">
    <form method="POST">
      <?=csrfField()?>
      <input type="hidden" name="change_password" value="1">
      <div style="margin-bottom:10px"><label class="form-label">Current Password</label><input type="password" name="old_password" class="form-input" required></div>
      <div style="margin-bottom:10px"><label class="form-label">New Password</label><input type="password" name="new_password" class="form-input" required placeholder="Min 8 characters"></div>
      <div style="margin-bottom:14px"><label class="form-label">Confirm New Password</label><input type="password" name="confirm_password" class="form-input" required></div>
      <button type="submit" class="btn btn-ghost" style="width:100%;justify-content:center">🔐 Change Password</button>
    </form>
  </div>
</div>

<!-- Support -->
<div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:12px;padding:14px 16px">
  <div style="font-size:13px;font-weight:700;color:#14532D;margin-bottom:6px">📞 Need Help?</div>
  <div style="font-size:12.5px;color:#166534;line-height:1.6">Contact Dausto support for any issues with your account, KYC, or payouts.</div>
  <a href="https://wa.me/919319300883" target="_blank" style="display:inline-block;margin-top:10px;background:#16A34A;color:#fff;padding:8px 16px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:700">💬 WhatsApp Support</a>
</div>
```

  </div>
</div>
</div>
</main>
</body></html>