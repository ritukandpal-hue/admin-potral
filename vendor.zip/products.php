<?php
// FILE: public_html/vendor/products.php
// Dausto vendor product manager — v3
// CHANGES vs v2:
//   + Short name + Logo-customisable checkbox (Basic)
//   + Product video URL (Media tab)
//   + Bulk price tiers (Stock & Pricing)
//   + Variant stock — one attribute with per-value qty (Stock & Pricing)
//   + Customisation tab — printing methods + placement zones (chips)
//   + Occasions tab — ideal occasions with icon/name/season
//   + FAQs tab — Q&A rows
//   + SEO tab — meta title + meta description with char counters
//   + Full audit logging for every new field/section
//
// All schema already exists in products / product_price_tiers /
// product_attribute_groups / product_attribute_options / product_faqs.
// WAF-safe: no inline event attrs, addEventListener only.

$config_locations = [
    '/home/u624259711/domains/orchid-alligator-169347.hostingersite.com/public_html/config.php',
    dirname(__DIR__) . '/config.php',
];
foreach ($config_locations as $c) { if (file_exists($c)) { require_once $c; break; } }
if (!defined('PUBLIC_PATH')) die('<p style="color:red;padding:40px">config.php not found</p>');

require_once PUBLIC_PATH . '/includes/db.php';
require_once PUBLIC_PATH . '/includes/auth.php';
require_once PUBLIC_PATH . '/includes/functions.php';
require_once PUBLIC_PATH . '/includes/product_audit.php';  // FILE: public_html/includes/product_audit.php

if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_httponly' => true,
        'cookie_secure'   => isset($_SERVER['HTTPS']),
        'cookie_samesite' => 'Lax',
        'use_strict_mode' => true,
    ]);
}
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

if (empty($_SESSION['user_id']) || ($_SESSION['portal'] ?? '') !== 'vendor') {
    header('Location: ' . SITE_URL . '/vendor/login.php');
    exit;
}

$user = currentUser();
$db   = getDB();

$vendor_stmt = $db->prepare("SELECT * FROM vendors WHERE user_id = ?");
$vendor_stmt->execute([$user['id']]);
$vendor = $vendor_stmt->fetch();
if (!$vendor) die('<p style="color:red;padding:40px">Vendor profile not found.</p>');
$vid = (int)$vendor['id'];

$actor = [
    'id'   => (int)$user['id'],
    'type' => 'vendor',
    'name' => $vendor['company_name'] ?? $user['name'] ?? 'Vendor',
];

$action = clean($_GET['action'] ?? 'list');
$msg = '';
$error = '';
$post_preserved = [];

// ====================================================================
// AJAX: image delete / set-primary
// ====================================================================
if (isset($_GET['img_action'])) {
    header('Content-Type: application/json');
    $img_id  = cleanInt($_GET['img_id']  ?? 0);
    $prod_id = cleanInt($_GET['prod_id'] ?? 0);
    if ($img_id && $prod_id) {
        $chk = $db->prepare("SELECT pi.image_path FROM product_images pi
                             JOIN products p ON p.id = pi.product_id
                             WHERE pi.id = ? AND p.vendor_id = ? LIMIT 1");
        $chk->execute([$img_id, $vid]);
        $row = $chk->fetch();
        if ($row) {
            if ($_GET['img_action'] === 'delete') {
                $f = PUBLIC_PATH . $row['image_path'];
                if (file_exists($f)) @unlink($f);
                $db->prepare("DELETE FROM product_images WHERE id = ?")->execute([$img_id]);
                logProductAction($prod_id, 'image_removed', $actor + ['notes' => 'Image #' . $img_id]);
                echo json_encode(['ok' => true]); exit;
            }
            if ($_GET['img_action'] === 'set_primary') {
                $db->prepare("UPDATE product_images SET is_primary = 0 WHERE product_id = ?")->execute([$prod_id]);
                $db->prepare("UPDATE product_images SET is_primary = 1 WHERE id = ?")->execute([$img_id]);
                logProductAction($prod_id, 'updated', $actor + ['field_changed' => 'primary_image', 'new_value' => 'img#' . $img_id]);
                echo json_encode(['ok' => true]); exit;
            }
        }
    }
    echo json_encode(['ok' => false]); exit;
}

// ====================================================================
// POST: save product
// ====================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        $error = 'Invalid form submission. Please refresh and try again.';
        goto render;
    }

    if (isset($_POST['save_product'])) {
        // ---- Basic ----
        $id          = cleanInt($_POST['product_id'] ?? 0);
        $name        = clean($_POST['name']        ?? '');
        $short_name  = clean($_POST['short_name']  ?? '');
        $category_id = cleanInt($_POST['category_id'] ?? 0) ?: null;
        $material    = clean($_POST['material']    ?? '');
        $description = clean($_POST['description'] ?? '');
        $is_customisable = isset($_POST['is_customisable']) ? 1 : 0;

        // ---- Pricing ----
        $base_price  = (float)($_POST['base_vendor_price'] ?? 0);
        $mrp         = (float)($_POST['mrp']        ?? 0);
        $moq         = cleanInt($_POST['moq']       ?? 10);
        $stock       = cleanInt($_POST['stock_qty'] ?? 0);
        $low_stock   = cleanInt($_POST['low_stock_alert'] ?? 20);
        $hsn         = clean($_POST['hsn_code']     ?? '');
        $gst_rate    = (float)($_POST['gst_rate']   ?? 18);
        $weight_g    = cleanInt($_POST['weight_grams'] ?? 0) ?: null;
        $lead_time   = max(0, min(60, cleanInt($_POST['lead_time_days'] ?? 0)));
        $restock_in  = clean($_POST['restock_date'] ?? '');
        $restock_date = ($restock_in && strtotime($restock_in)) ? date('Y-m-d', strtotime($restock_in)) : null;

        // ---- Media ----
        $video_url   = clean($_POST['video_url']    ?? '');

        // ---- Tags & keywords ----
        $tags_raw = clean($_POST['tags_input'] ?? '');
        $tags_arr = $tags_raw
            ? array_values(array_filter(array_map('trim', explode(',', $tags_raw))))
            : [];
        $tags_json = $tags_arr ? json_encode($tags_arr, JSON_UNESCAPED_UNICODE) : '[]';
        $keywords  = substr(clean($_POST['keywords_search'] ?? ''), 0, 500);

        // ---- Secondary categories ----
        $sec_cats = isset($_POST['secondary_categories']) && is_array($_POST['secondary_categories'])
            ? array_values(array_unique(array_filter(array_map('intval', $_POST['secondary_categories']))))
            : [];
        if ($category_id) $sec_cats = array_values(array_diff($sec_cats, [(int)$category_id]));
        $sec_cats_json = $sec_cats ? json_encode($sec_cats) : null;

        // ---- Features ----
        $features_arr = array_values(array_filter(array_map('trim', explode("\n", $_POST['features_input'] ?? ''))));
        $features_json = $features_arr ? json_encode($features_arr, JSON_UNESCAPED_UNICODE) : '[]';

        // ---- Customisation ----
        $print_raw   = clean($_POST['printing_input']  ?? '');
        $place_raw   = clean($_POST['placement_input'] ?? '');
        $print_json  = $print_raw
            ? json_encode(array_values(array_filter(array_map('trim', explode(',', $print_raw)))), JSON_UNESCAPED_UNICODE)
            : '[]';
        $place_json  = $place_raw
            ? json_encode(array_values(array_filter(array_map('trim', explode(',', $place_raw)))), JSON_UNESCAPED_UNICODE)
            : '[]';
        $ai_print    = clean($_POST['ai_suggest_print'] ?? '');

        // ---- Occasions ----
        $occ_json = clean($_POST['ideal_occasions_items'] ?? '');
        // basic sanity: must be valid JSON if non-empty
        if ($occ_json !== '' && json_decode($occ_json, true) === null) $occ_json = null;

        // ---- SEO ----
        $meta_title = substr(clean($_POST['meta_title'] ?? ''), 0, 200);
        $meta_desc  = substr(clean($_POST['meta_desc']  ?? ''), 0, 320);

        // ---- Validation ----
        if (empty($name) || $base_price <= 0 || $mrp <= 0) {
            $error = 'Product name, your price, and MRP are required.';
            $action = $id > 0 ? 'edit' : 'add';
            $post_preserved = $_POST;
            goto render;
        }
        if ($mrp < $base_price) {
            $error = 'MRP cannot be lower than your price.';
            $action = $id > 0 ? 'edit' : 'add';
            $post_preserved = $_POST;
            goto render;
        }

        $is_submit  = isset($_POST['submit_for_review']);
        $target_status = $is_submit ? 'pending' : 'draft';
        $sell_price = round($base_price * 1.10, 2);

        try {
            if ($id > 0) {
                // ---- UPDATE ----
                $own = $db->prepare("SELECT * FROM products WHERE id = ? AND vendor_id = ? LIMIT 1");
                $own->execute([$id, $vid]);
                $before = $own->fetch();
                if (!$before) {
                    $error = 'Product not found or not owned by you.';
                    $action = 'list'; goto render;
                }

                if ($before['status'] === 'active') {
                    $target_status = $is_submit ? 'pending' : 'draft';
                }

                $sql = "UPDATE products SET
                    name = ?, short_name = ?, category_id = ?, secondary_categories = ?,
                    material = ?, description = ?, features = ?,
                    base_vendor_price = ?, dausto_sell_price = ?, mrp = ?,
                    moq = ?, stock_qty = ?, low_stock_alert = ?,
                    restock_date = ?, lead_time_days = ?,
                    hsn_code = ?, gst_rate = ?, weight_grams = ?,
                    is_customisable = ?, video_url = ?,
                    printing_options = ?, placement_options = ?, ai_suggest_print = ?,
                    ideal_occasions = ?,
                    tags = ?, keywords_search = ?,
                    meta_title = ?, meta_desc = ?,
                    status = ?,
                    submitted_at = " . ($is_submit ? "NOW()" : "submitted_at") . ",
                    updated_at = NOW()
                    WHERE id = ? AND vendor_id = ?";
                $db->prepare($sql)->execute([
                    $name, $short_name, $category_id, $sec_cats_json,
                    $material, $description, $features_json,
                    $base_price, $sell_price, $mrp,
                    $moq, $stock, $low_stock,
                    $restock_date, $lead_time,
                    $hsn, $gst_rate, $weight_g,
                    $is_customisable, $video_url,
                    $print_json, $place_json, $ai_print,
                    $occ_json,
                    $tags_json, $keywords,
                    $meta_title, $meta_desc,
                    $target_status,
                    $id, $vid,
                ]);

                // Audit field diffs
                logProductFieldChanges($id, $before, [
                    'name' => $name, 'short_name' => $short_name,
                    'category_id' => $category_id, 'material' => $material, 'description' => $description,
                    'base_vendor_price' => $base_price, 'mrp' => $mrp, 'moq' => $moq, 'stock_qty' => $stock,
                    'restock_date' => $restock_date, 'lead_time_days' => $lead_time,
                    'hsn_code' => $hsn, 'gst_rate' => $gst_rate,
                    'is_customisable' => $is_customisable, 'video_url' => $video_url,
                    'printing_options' => $print_json, 'placement_options' => $place_json,
                    'ai_suggest_print' => $ai_print, 'ideal_occasions' => $occ_json,
                    'tags' => $tags_json, 'keywords_search' => $keywords,
                    'meta_title' => $meta_title, 'meta_desc' => $meta_desc,
                ], [
                    'name','short_name','category_id','material','description',
                    'base_vendor_price','mrp','moq','stock_qty','restock_date','lead_time_days',
                    'hsn_code','gst_rate','is_customisable','video_url',
                    'printing_options','placement_options','ai_suggest_print','ideal_occasions',
                    'tags','keywords_search','meta_title','meta_desc',
                ], $actor);

                if ($before['status'] !== $target_status) {
                    logProductAction($id, $is_submit ? 'submitted' : 'status_changed', $actor + [
                        'field_changed' => 'status',
                        'old_value'     => $before['status'],
                        'new_value'     => $target_status,
                        'notes'         => $is_submit ? 'Vendor submitted for admin review' : 'Saved as draft',
                    ]);
                }

                $msg = $is_submit
                    ? 'Saved & submitted for Dausto review.'
                    : 'Saved as DRAFT. Click "Submit for Review" when ready.';
            } else {
                // ---- INSERT ----
                $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name)) . '-' . time();
                $cols = ['vendor_id','name','short_name','slug','category_id','secondary_categories',
                         'material','description','features',
                         'base_vendor_price','dausto_sell_price','mrp',
                         'moq','stock_qty','low_stock_alert',
                         'restock_date','lead_time_days',
                         'hsn_code','gst_rate','weight_grams',
                         'is_customisable','video_url',
                         'printing_options','placement_options','ai_suggest_print',
                         'ideal_occasions',
                         'tags','keywords_search',
                         'meta_title','meta_desc',
                         'status','created_at'];
                $vals = [$vid,$name,$short_name,$slug,$category_id,$sec_cats_json,
                         $material,$description,$features_json,
                         $base_price,$sell_price,$mrp,
                         $moq,$stock,$low_stock,
                         $restock_date,$lead_time,
                         $hsn,$gst_rate,$weight_g,
                         $is_customisable,$video_url,
                         $print_json,$place_json,$ai_print,
                         $occ_json,
                         $tags_json,$keywords,
                         $meta_title,$meta_desc,
                         $target_status,date('Y-m-d H:i:s')];
                if ($is_submit) { $cols[] = 'submitted_at'; $vals[] = date('Y-m-d H:i:s'); }

                $ph = implode(',', array_fill(0, count($vals), '?'));
                $db->prepare("INSERT INTO products (" . implode(',', $cols) . ") VALUES ($ph)")->execute($vals);
                $id = (int)$db->lastInsertId();

                logProductAction($id, 'created', $actor + ['notes' => 'Created with status: ' . $target_status]);
                if ($is_submit) {
                    logProductAction($id, 'submitted', $actor + ['notes' => 'New product submitted for review']);
                }

                $msg = $is_submit
                    ? 'Product created & submitted for Dausto review.'
                    : 'Product saved as DRAFT. Add images & details, then submit when ready.';
            }

            // ---- Bulk price tiers (DELETE then INSERT) ----
            try {
                $db->prepare("DELETE FROM product_price_tiers WHERE product_id = ?")->execute([$id]);
                if (isset($_POST['tier_price']) && is_array($_POST['tier_price'])) {
                    foreach ($_POST['tier_price'] as $ti => $price) {
                        $price = (float)$price;
                        if ($price <= 0) continue;
                        $min = max(1, (int)($_POST['tier_min'][$ti] ?? 1));
                        $max = (($_POST['tier_max'][$ti] ?? '') !== '') ? (int)$_POST['tier_max'][$ti] : null;
                        $lbl = clean($_POST['tier_label'][$ti] ?? '');
                        $db->prepare("INSERT INTO product_price_tiers
                            (product_id, min_qty, max_qty, price, label, sort_order)
                            VALUES (?, ?, ?, ?, ?, ?)")->execute([$id, $min, $max, $price, $lbl, $ti]);
                    }
                    logProductAction($id, 'price_changed', $actor + ['notes' => 'Bulk price tiers updated']);
                }
            } catch (\Throwable $e) {}

            // ---- Variant stock (sort_order = -1 sentinel) ----
            try {
                $vname = clean($_POST['variant_attr_name'] ?? '');
                $vreq  = (int)($_POST['variant_attr_required'] ?? 1);
                $vvals = $_POST['variant_val'] ?? [];
                $vqtys = $_POST['variant_qty'] ?? [];

                // Wipe existing variant group for this product
                $old = $db->prepare("SELECT id FROM product_attribute_groups WHERE product_id = ? AND sort_order = -1");
                $old->execute([$id]);
                foreach ($old->fetchAll() as $r) {
                    $db->prepare("DELETE FROM product_attribute_options WHERE group_id = ?")->execute([$r['id']]);
                    $db->prepare("DELETE FROM product_attribute_groups  WHERE id = ?")->execute([$r['id']]);
                }
                if (!empty($vname) && is_array($vvals)) {
                    $db->prepare("INSERT INTO product_attribute_groups
                        (product_id, name, type, is_required, sort_order)
                        VALUES (?, ?, 'dropdown', ?, -1)")->execute([$id, $vname, $vreq]);
                    $gid = (int)$db->lastInsertId();
                    foreach ($vvals as $vi => $val) {
                        $val = clean($val);
                        if ($val === '') continue;
                        $qty = (int)($vqtys[$vi] ?? 0);
                        $db->prepare("INSERT INTO product_attribute_options
                            (group_id, product_id, value, stock_qty, is_available, sort_order)
                            VALUES (?, ?, ?, ?, ?, ?)")
                            ->execute([$gid, $id, $val, $qty, $qty > 0 ? 1 : 0, $vi]);
                    }
                    logProductAction($id, 'stock_changed', $actor + ['notes' => 'Variant stock updated: ' . $vname]);
                }
            } catch (\Throwable $e) {}

            // ---- FAQs (DELETE then INSERT) ----
            try {
                $db->prepare("DELETE FROM product_faqs WHERE product_id = ?")->execute([$id]);
                if (isset($_POST['faq_question']) && is_array($_POST['faq_question'])) {
                    $faq_count = 0;
                    foreach ($_POST['faq_question'] as $fi => $fq) {
                        $fq = clean($fq);
                        $fa = clean($_POST['faq_answer'][$fi] ?? '');
                        if ($fq === '' || $fa === '') continue;
                        $db->prepare("INSERT INTO product_faqs
                            (product_id, question, answer, sort_order, is_active)
                            VALUES (?, ?, ?, ?, 1)")->execute([$id, $fq, $fa, $fi]);
                        $faq_count++;
                    }
                    if ($faq_count > 0) {
                        logProductAction($id, 'updated', $actor + ['field_changed' => 'faqs', 'notes' => $faq_count . ' FAQ(s) saved']);
                    }
                }
            } catch (\Throwable $e) {}

            // ---- Image uploads ----
            if (!empty($_FILES['product_images']['name'][0])) {
                $ud = PUBLIC_PATH . '/uploads/products/';
                if (!is_dir($ud)) @mkdir($ud, 0755, true);
                $allowed = ['jpg', 'jpeg', 'png', 'webp'];
                $existing = (int)$db->query("SELECT COUNT(*) FROM product_images WHERE product_id = $id")->fetchColumn();
                $saved = 0;
                foreach ($_FILES['product_images']['tmp_name'] as $i => $tmp) {
                    if (($existing + $saved) >= 4) break;
                    if ($_FILES['product_images']['error'][$i] || !is_uploaded_file($tmp)) continue;
                    $size = (int)($_FILES['product_images']['size'][$i] ?? 0);
                    if ($size > 5 * 1024 * 1024) continue;
                    $ext = strtolower(pathinfo($_FILES['product_images']['name'][$i], PATHINFO_EXTENSION));
                    if (!in_array($ext, $allowed, true)) continue;
                    $fn = 'prod_' . $id . '_' . time() . '_' . random_int(1000, 9999) . '.' . $ext;
                    if (move_uploaded_file($tmp, $ud . $fn)) {
                        $is_primary = (($existing + $saved) === 0) ? 1 : 0;
                        $db->prepare("INSERT INTO product_images
                            (product_id, image_path, is_primary, sort_order, created_at)
                            VALUES (?, ?, ?, ?, NOW())")
                            ->execute([$id, '/uploads/products/' . $fn, $is_primary, $existing + $saved]);
                        logProductAction($id, 'image_added', $actor + ['new_value' => $fn]);
                        $saved++;
                    }
                }
            }

            $redir_msg = urlencode($msg);
            header('Location: products.php?action=edit&id=' . $id . '&saved=1&msg=' . $redir_msg);
            exit;
        } catch (\Throwable $e) {
            $error = 'Save failed: ' . $e->getMessage();
            $action = $id > 0 ? 'edit' : 'add';
            $post_preserved = $_POST;
            goto render;
        }
    }
}

render:

if (!empty($_GET['saved']) && !empty($_GET['msg'])) {
    $msg = htmlspecialchars(strip_tags(urldecode($_GET['msg'])));
}

$categories = $db->query("SELECT id, name, parent_id FROM categories
                          WHERE is_active = 1 ORDER BY parent_id, name")->fetchAll();

$search    = clean($_GET['q']      ?? '');
$st_filter = clean($_GET['status'] ?? '');
$page      = max(1, cleanInt($_GET['page'] ?? 1));
$per_page  = 20;

$where  = ["p.vendor_id = $vid"];
$params = [];
if ($search)    { $where[] = "p.name LIKE ?";   $params[] = "%$search%"; }
if ($st_filter) { $where[] = "p.status = ?";    $params[] = $st_filter;  }
$wsql = implode(' AND ', $where);

$tc = $db->prepare("SELECT COUNT(*) FROM products p WHERE $wsql");
$tc->execute($params);
$total = (int)$tc->fetchColumn();
$pag = paginate($total, $per_page, $page, 'products.php');

$stmt = $db->prepare("SELECT p.*, c.name cat_name, pi2.image_path primary_image,
    (SELECT COUNT(*) FROM product_images WHERE product_id = p.id) img_count
    FROM products p
    LEFT JOIN categories c ON c.id = p.category_id
    LEFT JOIN product_images pi2 ON pi2.product_id = p.id AND pi2.is_primary = 1
    WHERE $wsql
    ORDER BY p.updated_at DESC, p.id DESC
    LIMIT $per_page OFFSET {$pag['offset']}");
$stmt->execute($params);
$products = $stmt->fetchAll();

$status_counts = ['all'=>$total,'draft'=>0,'pending'=>0,'active'=>0,'rejected'=>0,'inactive'=>0,'out_of_stock'=>0];
try {
    $sc = $db->prepare("SELECT status, COUNT(*) c FROM products WHERE vendor_id = ? GROUP BY status");
    $sc->execute([$vid]);
    foreach ($sc->fetchAll() as $r) {
        if (isset($status_counts[$r['status']])) $status_counts[$r['status']] = (int)$r['c'];
    }
} catch (\Throwable $e) {}

// ---- Edit context ----
$edit_product = null;
$edit_images  = [];
$edit_audit   = [];
$edit_tiers   = [];
$edit_faqs    = [];
$edit_variant_group = null;
$edit_variant_opts  = [];

if ($action === 'edit' && isset($_GET['id'])) {
    $ep = $db->prepare("SELECT * FROM products WHERE id = ? AND vendor_id = ?");
    $ep->execute([cleanInt($_GET['id']), $vid]);
    $edit_product = $ep->fetch();
    if (!$edit_product) {
        $action = 'list';
    } else {
        $pid = (int)$edit_product['id'];
        $ei = $db->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_primary DESC, sort_order");
        $ei->execute([$pid]); $edit_images = $ei->fetchAll();
        $edit_audit = getProductAuditLog($pid, 50);
        try {
            $et = $db->prepare("SELECT * FROM product_price_tiers WHERE product_id = ? ORDER BY sort_order, min_qty");
            $et->execute([$pid]); $edit_tiers = $et->fetchAll();
        } catch (\Throwable $e) {}
        try {
            $ef = $db->prepare("SELECT * FROM product_faqs WHERE product_id = ? AND is_active = 1 ORDER BY sort_order");
            $ef->execute([$pid]); $edit_faqs = $ef->fetchAll();
        } catch (\Throwable $e) {}
        try {
            $evg = $db->prepare("SELECT * FROM product_attribute_groups WHERE product_id = ? AND sort_order = -1 LIMIT 1");
            $evg->execute([$pid]);
            $vg = $evg->fetch();
            if ($vg) {
                $edit_variant_group = $vg;
                $evo = $db->prepare("SELECT * FROM product_attribute_options WHERE group_id = ? ORDER BY sort_order");
                $evo->execute([$vg['id']]);
                $edit_variant_opts = $evo->fetchAll();
            }
        } catch (\Throwable $e) {}
    }
}

$ep = $edit_product ?? [];
if (!empty($post_preserved) && !empty($error)) {
    foreach ($post_preserved as $k => $v) {
        if (!is_array($v)) $ep[$k] = $v;
    }
}

// Secondary categories prefill
$sec_cats_selected = [];
if (!empty($ep['secondary_categories'])) {
    $sec_cats_selected = json_decode($ep['secondary_categories'], true) ?: [];
}
if (isset($post_preserved['secondary_categories']) && is_array($post_preserved['secondary_categories'])) {
    $sec_cats_selected = array_map('intval', $post_preserved['secondary_categories']);
}

// Customisation prefill
$sel_print = json_decode($ep['printing_options']  ?? '[]', true) ?: [];
$sel_place = json_decode($ep['placement_options'] ?? '[]', true) ?: [];
$print_opts = ['Screen Printing','Laser Engraving','UV Printing','Embroidery','Pad Printing',
               'Digital Printing','Sublimation','Gold Foil','Silver Foil','Debossing','Embossing','Heat Transfer'];
$place_opts = ['Front','Back','Left Side','Right Side','Top','Bottom','Inner','Sleeve','Collar','Pocket','Handle','Lid','Base'];
$ai_opts    = ['Screen Printing','Laser Engraving','UV Printing','Embroidery','Pad Printing','Sublimation','Gold Foil','Debossing'];

// Occasions prefill (with defaults to seed empty rows)
$occ_default = [
    ['icon'=>'🎉','name'=>'Diwali Gifting','when'=>'Oct-Nov'],
    ['icon'=>'👋','name'=>'Employee Onboarding','when'=>'Year-round'],
    ['icon'=>'🤝','name'=>'Client Gifts','when'=>'Q4'],
];
$occ_existing = json_decode($ep['ideal_occasions'] ?? '[]', true) ?: $occ_default;

if (!function_exists('istFmt')) {
    function istFmt(?string $ts): string {
        if (!$ts) return '—';
        try {
            $dt = new DateTime($ts, new DateTimeZone('UTC'));
            $dt->setTimezone(new DateTimeZone('Asia/Kolkata'));
            return $dt->format('d M Y, h:i A');
        } catch (\Throwable $e) { return $ts; }
    }
}
if (!function_exists('vendorNav')) {
    function vendorNav(string $href, string $icon, string $label, bool $active = false): string {
        $bg = $active ? 'background:#D97706;color:#fff;box-shadow:0 2px 10px rgba(217,119,6,.4)'
                      : 'color:rgba(255,255,255,.55)';
        return '<a href="' . $href . '" style="display:flex;align-items:center;gap:10px;'
             . 'padding:9px 14px 9px 18px;margin:1px 8px;border-radius:9px;font-size:13px;'
             . 'font-weight:600;text-decoration:none;' . $bg . '">'
             . '<span style="width:22px;text-align:center;font-size:16px">' . $icon . '</span>'
             . $label . '</a>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Products — Dausto Vendor</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700;800;900&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'DM Sans',sans-serif;background:#F0F2F5;color:#0F172A}
.sidebar{position:fixed;top:0;left:0;bottom:0;width:240px;background:linear-gradient(180deg,#1E2F7A,#2E3D9A);display:flex;flex-direction:column;z-index:100}
.sidebar-nav{flex:1;overflow-y:auto;padding:8px 0}
.nav-group{font-size:9.5px;font-weight:700;color:rgba(255,255,255,.2);letter-spacing:.12em;padding:12px 22px 4px}
.main{margin-left:240px;min-height:100vh}
.topbar{background:#fff;border-bottom:1px solid #E2E8F0;padding:14px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:40;box-shadow:0 1px 4px rgba(0,0,0,.05)}
.card{background:#fff;border-radius:14px;border:1px solid #E8ECF2;box-shadow:0 1px 4px rgba(0,0,0,.04);overflow:hidden;margin-bottom:16px}
.card-head{padding:14px 18px;border-bottom:1px solid #F0F3F6;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
.card-title{font-size:14px;font-weight:800;color:#0F172A}
.btn{padding:9px 18px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;border:none;text-decoration:none;display:inline-flex;align-items:center;gap:6px;font-family:'DM Sans',sans-serif}
.btn-primary{background:#D97706;color:#fff}
.btn-submit{background:#16A34A;color:#fff}
.btn-ghost{background:#F8FAFC;color:#374151;border:1px solid #E2E8F0}
.btn-sm{padding:6px 14px;font-size:12.5px;border-radius:8px}
.btn-xs{padding:3px 9px;font-size:11px;border-radius:6px}
.form-label{display:block;font-size:11px;font-weight:700;color:#374151;letter-spacing:.06em;margin-bottom:5px;text-transform:uppercase}
.form-input{width:100%;border:1.5px solid #E2E8F0;border-radius:9px;padding:10px 13px;font-size:13.5px;color:#0F172A;font-family:'DM Sans',sans-serif;outline:none;background:#FAFBFC}
.form-input:focus{border-color:#D97706;box-shadow:0 0 0 3px rgba(217,119,6,.15);background:#fff}
textarea.form-input{resize:vertical;min-height:80px}
.tbl{width:100%;border-collapse:collapse}
.tbl th{background:#F8FAFC;padding:10px 14px;font-size:10.5px;font-weight:700;color:#64748B;letter-spacing:.06em;text-align:left;border-bottom:1px solid #F0F3F6}
.tbl td{padding:11px 14px;font-size:13px;color:#374151;border-bottom:1px solid #F8FAFC;vertical-align:middle}
.tbl tbody tr:hover td{background:#FAFBFC}
.pill{display:inline-block;padding:2px 9px;border-radius:20px;font-size:11px;font-weight:700;white-space:nowrap}
.alert{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:16px;display:flex;align-items:flex-start;gap:10px}
.alert-success{background:#F0FDF4;border:1px solid #BBF7D0;color:#14532D}
.alert-error{background:#FEF2F2;border:1.5px solid #FECACA;color:#7F1D1D}
.alert-info{background:#EEF0FB;border:1px solid #C7D0F7;color:#1E2F7A}
.tab-nav{display:flex;gap:3px;border-bottom:2px solid #E2E8F0;margin-bottom:18px;overflow-x:auto}
.tab-btn{padding:9px 14px;font-size:12.5px;font-weight:700;cursor:pointer;border:none;background:transparent;color:#64748B;font-family:'DM Sans',sans-serif;border-bottom:3px solid transparent;margin-bottom:-2px;white-space:nowrap}
.tab-btn.active{color:#D97706;border-bottom-color:#D97706}
.tab-panel{display:none}
.tab-panel.show{display:block}
.g2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.fg{margin-bottom:14px}
.hint{font-size:11px;color:#94A3B8;margin-top:4px}
.slot-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:12px}
.img-slot{border-radius:10px;overflow:hidden;border:2px solid #E2E8F0;background:#F8FAFC;aspect-ratio:1;position:relative}
.img-slot.filled{border-color:#D97706}
.img-slot img{width:100%;height:100%;object-fit:cover}
.slot-lbl{position:absolute;top:5px;left:5px;background:#D97706;color:#fff;font-size:9px;font-weight:800;padding:2px 7px;border-radius:10px}
.slot-x{position:absolute;top:5px;right:5px;width:22px;height:22px;background:#DC2626;border:none;border-radius:50%;color:#fff;font-size:12px;cursor:pointer;z-index:5}
.slot-empty{border:2px dashed #C7D0F7;border-radius:10px;aspect-ratio:1;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;background:#F8FAFC;position:relative}
.slot-empty input{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%;height:100%;z-index:2}
.guideline{background:#FFFBEB;border:1px solid #FDE68A;border-radius:10px;padding:13px 16px;font-size:12.5px;color:#92400E;line-height:1.65;margin-bottom:14px}
.guideline strong{color:#78350F}
.audit-row{display:flex;gap:10px;padding:10px 12px;border-bottom:1px solid #F0F3F6;font-size:12.5px;align-items:flex-start}
.audit-row:last-child{border-bottom:none}
.audit-tag{font-size:10.5px;font-weight:700;padding:2px 8px;border-radius:14px;white-space:nowrap;flex-shrink:0}
.sec-cat-chip{display:inline-flex;align-items:center;gap:6px;padding:5px 11px;border-radius:18px;font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid #E2E8F0;background:#fff;color:#374151;margin:3px}
.sec-cat-chip.sel{background:#D97706;border-color:#D97706;color:#fff}
.mchip{padding:5px 12px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;border:1.5px solid #E2E8F0;background:#fff;color:#374151;display:inline-block;margin:3px;user-select:none}
.mchip.sel{background:#D97706;border-color:#D97706;color:#fff}
.chip-box{display:flex;flex-wrap:wrap;gap:6px;padding:10px;border:1.5px solid #E2E8F0;border-radius:9px;background:#FAFBFC;min-height:44px}
.chip-inp{border:none;outline:none;font-size:12px;color:#374151;font-family:'DM Sans',sans-serif;width:120px;background:transparent;padding:4px}
.rm-btn{background:#FEE2E2;border:none;border-radius:6px;width:28px;height:28px;cursor:pointer;font-size:13px;color:#DC2626;display:flex;align-items:center;justify-content:center}
.attr-row{background:#F8FAFC;border:1px solid #E8ECF2;border-radius:10px;padding:14px 16px;margin-bottom:10px;position:relative}
.status-draft{background:#F1F5F9;color:#475569}
.status-pending{background:#FEF3C7;color:#92400E}
.status-active{background:#D1FAE5;color:#14532D}
.status-rejected{background:#FEE2E2;color:#7F1D1D}
.status-inactive{background:#F1F5F9;color:#475569}
.status-out_of_stock{background:#FEE2E2;color:#7F1D1D}
</style>
</head>
<body>

<aside class="sidebar">
  <!-- Brand logo. FILE: public_html/dausto.png -->
  <div style="padding:16px 16px 12px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:10px">
    <img src="<?= SITE_URL ?>/dausto.png" alt="Dausto" style="height:34px;width:auto;display:block">
  </div>
  <div style="padding:10px 16px;border-bottom:1px solid rgba(255,255,255,.07)">
    <div style="font-size:9.5px;color:rgba(255,255,255,.35);font-weight:700;letter-spacing:.12em">VENDOR PORTAL</div>
    <div style="font-size:13px;font-weight:700;color:#fff;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
      <?= htmlspecialchars(html_entity_decode($vendor['company_name'] ?? '', ENT_QUOTES, 'UTF-8')) ?>
    </div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-group">MAIN</div>
    <?= vendorNav('index.php',     '🏠', 'Dashboard') ?>
    <?= vendorNav('orders.php',    '📋', 'My Orders') ?>
    <div class="nav-group">CATALOGUE</div>
    <?= vendorNav('products.php',  '📦', 'My Products', true) ?>
    <?= vendorNav('inventory.php', '📊', 'Inventory') ?>
    <div class="nav-group">FINANCE</div>
    <?= vendorNav('earnings.php',  '💰', 'Earnings') ?>
    <div class="nav-group">ACCOUNT</div>
    <?= vendorNav('profile.php',   '👤', 'Profile') ?>
    <?= vendorNav('logout.php',    '⏻',  'Logout') ?>
  </nav>
</aside>

<main class="main">
  <div class="topbar">
    <div>
      <h1 style="font-size:20px;font-weight:900;font-family:'Playfair Display',serif">
        <?= $action === 'add' ? 'Add Product' : ($action === 'edit' ? 'Edit Product' : 'My Products') ?>
      </h1>
      <p style="font-size:12px;color:#94A3B8;margin-top:2px">
        <?= $total ?> products
        <?php if ($status_counts['draft']   > 0): ?> · <span style="color:#475569;font-weight:700"><?= $status_counts['draft'] ?> drafts</span><?php endif ?>
        <?php if ($status_counts['pending'] > 0): ?> · <span style="color:#D97706;font-weight:700"><?= $status_counts['pending'] ?> under review</span><?php endif ?>
        <?php if ($status_counts['rejected']> 0): ?> · <span style="color:#DC2626;font-weight:700"><?= $status_counts['rejected'] ?> rejected</span><?php endif ?>
      </p>
    </div>
    <div style="display:flex;gap:10px">
      <?php if ($action !== 'list'): ?>
        <a href="products.php" class="btn btn-ghost btn-sm">← Back</a>
      <?php else: ?>
        <a href="products.php?action=add" class="btn btn-primary">+ Add Product</a>
      <?php endif ?>
    </div>
  </div>

  <div style="padding:22px">

    <?php if ($msg): ?>
      <div class="alert alert-success">
        <span style="font-size:18px">✅</span>
        <div><strong>Saved.</strong> <?= htmlspecialchars($msg) ?></div>
      </div>
    <?php endif ?>

    <?php if ($error): ?>
      <div class="alert alert-error">
        <span style="font-size:22px">❌</span>
        <div>
          <div style="font-weight:800;margin-bottom:3px">Save failed — your data is preserved below</div>
          <div><?= htmlspecialchars($error) ?></div>
        </div>
      </div>
    <?php endif ?>

<?php if ($action === 'list'): ?>

    <div class="card" style="margin-bottom:14px">
      <div style="padding:12px 16px">
        <form method="GET" style="display:flex;gap:9px;flex-wrap:wrap;align-items:center">
          <input type="text" name="q" value="<?= htmlspecialchars($search) ?>"
                 placeholder="🔍 Search by name..." class="form-input"
                 style="width:240px;padding:8px 12px">
          <select name="status" class="form-input" style="width:180px;padding:8px 12px">
            <option value="">All Status</option>
            <?php foreach (['draft'=>'Draft','pending'=>'Pending Review','active'=>'Active',
                            'rejected'=>'Rejected','inactive'=>'Inactive','out_of_stock'=>'Out of Stock'] as $sv=>$sl): ?>
              <option value="<?= $sv ?>" <?= $st_filter===$sv?'selected':'' ?>>
                <?= $sl ?> (<?= $status_counts[$sv]??0 ?>)
              </option>
            <?php endforeach ?>
          </select>
          <button type="submit" class="btn btn-primary btn-sm">Filter</button>
          <a href="products.php" class="btn btn-ghost btn-sm">Clear</a>
        </form>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><div class="card-title">📦 My Products (<?= $total ?>)</div></div>
      <?php if (empty($products)): ?>
        <div style="padding:50px;text-align:center;color:#94A3B8">
          <div style="font-size:42px;margin-bottom:10px">📦</div>
          <div style="font-size:15px;font-weight:700;color:#374151">No products yet</div>
          <div style="font-size:13px;margin-top:6px;margin-bottom:16px">
            Add your first product. It will be saved as a draft until you submit it for review.
          </div>
          <a href="products.php?action=add" class="btn btn-primary">+ Add First Product</a>
        </div>
      <?php else: ?>
        <table class="tbl">
          <thead><tr>
            <th></th><th>PRODUCT</th><th>CATEGORY</th><th>YOUR PRICE</th>
            <th>STOCK</th><th>LEAD TIME</th><th>STATUS</th><th>UPDATED</th><th></th>
          </tr></thead>
          <tbody>
            <?php foreach ($products as $p): ?>
              <tr>
                <td style="width:48px">
                  <?php if (!empty($p['primary_image'])): ?>
                    <img src="<?= htmlspecialchars(SITE_URL . $p['primary_image']) ?>"
                         style="width:42px;height:42px;border-radius:7px;object-fit:cover;border:1px solid #E2E8F0">
                  <?php else: ?>
                    <div style="width:42px;height:42px;border-radius:7px;background:#F0F3F6;display:flex;align-items:center;justify-content:center;font-size:18px">📦</div>
                  <?php endif ?>
                </td>
                <td>
                  <div style="font-weight:700;font-size:13.5px"><?= htmlspecialchars($p['name']) ?></div>
                  <div style="font-size:10.5px;color:#94A3B8">
                    <?= $p['img_count'] ?? 0 ?> imgs · MOQ: <?= $p['moq'] ?>
                  </div>
                </td>
                <td style="font-size:12.5px;color:#64748B"><?= htmlspecialchars($p['cat_name'] ?? '—') ?></td>
                <td style="font-weight:700">Rs.<?= number_format((float)$p['base_vendor_price'], 0) ?></td>
                <td style="font-weight:700;color:<?= (int)$p['stock_qty'] <= (int)($p['low_stock_alert'] ?? 20) ? '#DC2626' : '#0F172A' ?>">
                  <?= $p['stock_qty'] ?>
                </td>
                <td style="font-size:12.5px"><?= (int)($p['lead_time_days'] ?? 0) ?> d</td>
                <td>
                  <span class="pill status-<?= htmlspecialchars($p['status']) ?>">
                    <?= ucwords(str_replace('_', ' ', $p['status'])) ?>
                  </span>
                </td>
                <td style="font-size:11.5px;color:#64748B"><?= istFmt($p['updated_at'] ?? $p['created_at']) ?></td>
                <td><a href="products.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-ghost btn-xs">✏️ Edit</a></td>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      <?php endif ?>
    </div>

<?php elseif ($action === 'add' || $action === 'edit'): $is_edit = ($action === 'edit' && $edit_product); ?>

    <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
      <a href="products.php" style="color:#64748B;text-decoration:none;font-size:13px;font-weight:600">← My Products</a>
      <span style="color:#E2E8F0">/</span>
      <span style="font-size:13px;font-weight:700">
        <?= $is_edit ? 'Edit: ' . htmlspecialchars($ep['name'] ?? '') : 'Add New Product' ?>
      </span>
      <?php if ($is_edit): ?>
        <span class="pill status-<?= htmlspecialchars($ep['status']) ?>" style="margin-left:6px">
          <?= ucwords(str_replace('_', ' ', $ep['status'])) ?>
        </span>
      <?php endif ?>
    </div>

    <?php if ($is_edit && ($ep['status'] ?? '') === 'rejected' && !empty($ep['rejection_reason'])): ?>
      <div class="alert alert-error">
        <span style="font-size:20px">⚠️</span>
        <div>
          <div style="font-weight:800;margin-bottom:3px">This product was rejected by Dausto</div>
          <div><?= htmlspecialchars($ep['rejection_reason']) ?></div>
        </div>
      </div>
    <?php endif ?>

    <div class="tab-nav" id="tabNav">
      <button type="button" class="tab-btn" data-tab="basic">📝 Basic</button>
      <button type="button" class="tab-btn" data-tab="pricing">💰 Stock &amp; Pricing</button>
      <button type="button" class="tab-btn" data-tab="categories">🗂️ Categories &amp; Tags</button>
      <button type="button" class="tab-btn" data-tab="media">📸 Images &amp; Video</button>
      <button type="button" class="tab-btn" data-tab="custom">🎨 Customisation</button>
      <button type="button" class="tab-btn" data-tab="occasions">🎉 Occasions</button>
      <button type="button" class="tab-btn" data-tab="faqs">❓ FAQs</button>
      <button type="button" class="tab-btn" data-tab="seo">🔍 SEO</button>
      <?php if ($is_edit): ?><button type="button" class="tab-btn" data-tab="audit">📜 History</button><?php endif ?>
    </div>

    <form method="POST" enctype="multipart/form-data" id="pForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
      <input type="hidden" name="save_product" value="1">
      <?php if ($is_edit): ?><input type="hidden" name="product_id" value="<?= $ep['id'] ?>"><?php endif ?>

      <div style="display:grid;grid-template-columns:1fr 280px;gap:18px">
        <div>

          <!-- =========== BASIC =========== -->
          <div id="tab-basic" class="tab-panel card" style="padding:18px">
            <div class="g2 fg">
              <div>
                <label class="form-label">Product Name *</label>
                <input type="text" name="name" class="form-input" required
                       value="<?= htmlspecialchars($ep['name'] ?? '') ?>"
                       placeholder="e.g. Premium Leather Diary A5">
              </div>
              <div>
                <label class="form-label">Short Name</label>
                <input type="text" name="short_name" class="form-input"
                       value="<?= htmlspecialchars($ep['short_name'] ?? '') ?>"
                       placeholder="e.g. Leather Diary">
                <div class="hint">Short version used on cards / lists</div>
              </div>
            </div>
            <div class="fg">
              <label class="form-label">Material</label>
              <input type="text" name="material" class="form-input"
                     value="<?= htmlspecialchars($ep['material'] ?? '') ?>"
                     placeholder="e.g. PU Leather, Cotton, Bamboo, Stainless Steel">
            </div>
            <div class="fg">
              <label class="form-label">Description</label>
              <textarea name="description" class="form-input" rows="4"
                        placeholder="Describe what makes this product great..."><?= htmlspecialchars($ep['description'] ?? '') ?></textarea>
            </div>
            <div class="fg">
              <label class="form-label">Key Features (one per line)</label>
              <textarea name="features_input" class="form-input" rows="4"
                        placeholder="Premium stitching&#10;Waterproof lining&#10;Lifetime warranty"><?php
                $fa = json_decode($ep['features'] ?? '[]', true) ?: [];
                echo htmlspecialchars(implode("\n", $fa));
              ?></textarea>
            </div>
            <div class="g3 fg">
              <div>
                <label class="form-label">HSN Code</label>
                <input type="text" name="hsn_code" class="form-input"
                       value="<?= htmlspecialchars($ep['hsn_code'] ?? '') ?>" placeholder="4820">
              </div>
              <div>
                <label class="form-label">GST Rate %</label>
                <select name="gst_rate" class="form-input">
                  <?php foreach ([0,5,12,18,28] as $r): ?>
                    <option value="<?= $r ?>" <?= ((float)($ep['gst_rate'] ?? 18) == $r) ? 'selected' : '' ?>><?= $r ?>%</option>
                  <?php endforeach ?>
                </select>
              </div>
              <div>
                <label class="form-label">Weight (g)</label>
                <input type="number" name="weight_grams" class="form-input" min="0"
                       value="<?= (int)($ep['weight_grams'] ?? 0) ?: '' ?>" placeholder="500">
              </div>
            </div>
            <div style="padding-top:10px;border-top:1px solid #F0F2F5">
              <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:13px">
                <input type="checkbox" name="is_customisable" value="1"
                       <?= ($ep['is_customisable'] ?? 1) ? 'checked' : '' ?>
                       style="accent-color:#D97706;width:16px;height:16px">
                <strong>Logo Customisable</strong>
                <span style="color:#94A3B8;font-size:11.5px">— Can client print their logo/text on this?</span>
              </label>
            </div>
          </div>

          <!-- =========== STOCK & PRICING =========== -->
          <div id="tab-pricing" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:14px">💰 Stock &amp; Pricing</div>

            <div class="g4 fg">
              <div>
                <label class="form-label">Your Price (Rs.) *</label>
                <input type="number" name="base_vendor_price" id="basePrice" class="form-input" required
                       min="0" step="0.01" value="<?= $ep['base_vendor_price'] ?? '' ?>" placeholder="100">
                <div class="hint">Price Dausto pays you per unit</div>
              </div>
              <div>
                <label class="form-label">MRP (Rs.) *</label>
                <input type="number" name="mrp" class="form-input" required min="0" step="0.01"
                       value="<?= $ep['mrp'] ?? '' ?>" placeholder="999">
              </div>
              <div>
                <label class="form-label">MOQ</label>
                <input type="number" name="moq" id="moqInp" class="form-input" min="1"
                       value="<?= $ep['moq'] ?? 10 ?>">
              </div>
              <div>
                <label class="form-label">Stock Qty</label>
                <input type="number" name="stock_qty" class="form-input" min="0"
                       value="<?= $ep['stock_qty'] ?? 0 ?>">
              </div>
            </div>

            <div class="g3 fg">
              <div>
                <label class="form-label">Low-Stock Alert</label>
                <input type="number" name="low_stock_alert" class="form-input" min="0"
                       value="<?= $ep['low_stock_alert'] ?? 20 ?>">
              </div>
              <div>
                <label class="form-label">⏱ Lead Time (days)</label>
                <input type="number" name="lead_time_days" class="form-input" min="0" max="60"
                       value="<?= (int)($ep['lead_time_days'] ?? 0) ?>" placeholder="3">
                <div class="hint">Production / prep time before dispatch</div>
              </div>
              <div>
                <label class="form-label">📅 Restock Date</label>
                <input type="date" name="restock_date" class="form-input"
                       value="<?= htmlspecialchars($ep['restock_date'] ?? '') ?>">
                <div class="hint">When OOS items return</div>
              </div>
            </div>

            <!-- BULK TIERS -->
            <div style="background:#F8FAFC;border:1px solid #E8ECF2;border-radius:10px;padding:14px 16px;margin-top:8px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                <div style="font-size:11.5px;font-weight:800;color:#374151;letter-spacing:.06em">
                  💸 BULK PRICE TIERS <span style="font-size:10.5px;color:#94A3B8;font-weight:400">— offer discounts for larger qty</span>
                </div>
                <button type="button" class="btn btn-ghost btn-sm" id="addTierBtn">+ Add Tier</button>
              </div>
              <div style="display:grid;grid-template-columns:80px 80px 130px 150px 34px;gap:8px;margin-bottom:6px">
                <div style="font-size:10px;font-weight:700;color:#94A3B8">FROM QTY</div>
                <div style="font-size:10px;font-weight:700;color:#94A3B8">TO QTY</div>
                <div style="font-size:10px;font-weight:700;color:#94A3B8">YOUR PRICE</div>
                <div style="font-size:10px;font-weight:700;color:#94A3B8">LABEL (optional)</div>
                <div></div>
              </div>
              <div id="tierList">
                <?php foreach ($edit_tiers as $ti => $t): ?>
                <div class="tier-row" style="display:grid;grid-template-columns:80px 80px 130px 150px 34px;gap:8px;margin-bottom:7px">
                  <input type="number" name="tier_min[]" class="form-input" value="<?= $t['min_qty'] ?>" min="1" style="padding:7px">
                  <input type="number" name="tier_max[]" class="form-input" value="<?= $t['max_qty'] ?? '' ?>" min="0" placeholder="∞" style="padding:7px">
                  <input type="number" name="tier_price[]" class="form-input" value="<?= $t['price'] ?>" min="0" step="0.01" style="padding:7px">
                  <select name="tier_label[]" class="form-input" style="padding:7px">
                    <option value="">—</option>
                    <?php foreach (['Trial / Sample','Small Team','Department','CSR Budget','Enterprise'] as $sl): ?>
                      <option value="<?= $sl ?>" <?= ($t['label'] ?? '') === $sl ? 'selected' : '' ?>><?= $sl ?></option>
                    <?php endforeach ?>
                  </select>
                  <button type="button" class="rm-btn rm-tier">✕</button>
                </div>
                <?php endforeach ?>
                <?php if (empty($edit_tiers)): ?>
                  <div id="noTierMsg" style="padding:16px;text-align:center;color:#94A3B8;border:2px dashed #E2E8F0;border-radius:8px;font-size:12.5px">
                    No bulk tiers. Add tiers to offer better pricing for larger orders.
                  </div>
                <?php endif ?>
              </div>
            </div>

            <!-- VARIANT STOCK -->
            <div style="margin-top:18px;padding-top:16px;border-top:2px dashed #E8ECF2">
              <div style="font-size:13px;font-weight:800;color:#0F172A;margin-bottom:4px">
                📦 Variant Stock <span style="font-size:11px;font-weight:400;color:#64748B">(optional — Size, Colour, or Capacity)</span>
              </div>
              <div style="font-size:12px;color:#64748B;background:#EEF0FB;border-radius:8px;padding:10px 13px;line-height:1.7;margin-bottom:12px">
                💡 Use this if your product comes in multiple <strong>sizes / colours / capacities</strong> with different stock counts. Price stays same — only qty per variant differs. Shows as dropdown on product page.
              </div>
              <div class="g2 fg" style="max-width:420px">
                <div>
                  <label class="form-label">Attribute Name</label>
                  <input type="text" name="variant_attr_name" class="form-input"
                         value="<?= htmlspecialchars($edit_variant_group['name'] ?? '') ?>"
                         placeholder="e.g. Size, Colour, Capacity">
                </div>
                <div>
                  <label class="form-label">Required?</label>
                  <select name="variant_attr_required" class="form-input">
                    <option value="1" <?= ($edit_variant_group['is_required'] ?? 1) ? 'selected' : '' ?>>Yes</option>
                    <option value="0" <?= !($edit_variant_group['is_required'] ?? 1) ? 'selected' : '' ?>>No</option>
                  </select>
                </div>
              </div>
              <div style="display:grid;grid-template-columns:1fr 130px 34px;gap:8px;margin-bottom:7px">
                <div class="form-label" style="margin-bottom:0">VALUE (e.g. M, L, Red)</div>
                <div class="form-label" style="margin-bottom:0;text-align:center">QTY AVAILABLE</div>
                <div></div>
              </div>
              <div id="varList">
                <?php foreach ($edit_variant_opts as $vo): ?>
                <div class="var-row" style="display:grid;grid-template-columns:1fr 130px 34px;gap:8px;margin-bottom:7px">
                  <input type="text" name="variant_val[]" class="form-input" value="<?= htmlspecialchars($vo['value'] ?? '') ?>" placeholder="e.g. M, Red">
                  <input type="number" name="variant_qty[]" class="form-input" value="<?= (int)($vo['stock_qty'] ?? 0) ?>" min="0" style="text-align:center">
                  <button type="button" class="rm-btn rm-var">✕</button>
                </div>
                <?php endforeach ?>
              </div>
              <button type="button" class="btn btn-ghost btn-sm" id="addVarBtn">+ Add Variant</button>
            </div>
          </div>

          <!-- =========== CATEGORIES =========== -->
          <div id="tab-categories" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:14px">🗂️ Categories, Tags &amp; Keywords</div>
            <div class="fg">
              <label class="form-label">Primary Category *</label>
              <select name="category_id" class="form-input" id="primaryCat">
                <option value="">— Select main category —</option>
                <?php foreach ($categories as $cat): ?>
                  <option value="<?= $cat['id'] ?>" <?= ((int)($ep['category_id'] ?? 0) === (int)$cat['id']) ? 'selected' : '' ?>>
                    <?= $cat['parent_id'] ? '  — ' : '' ?><?= htmlspecialchars($cat['name']) ?>
                  </option>
                <?php endforeach ?>
              </select>
            </div>
            <div class="fg">
              <label class="form-label">Secondary Categories (optional)</label>
              <div id="secCatBox" style="display:flex;flex-wrap:wrap;gap:4px;padding:10px;border:1.5px solid #E2E8F0;border-radius:9px;background:#FAFBFC;min-height:50px">
                <?php foreach ($categories as $cat):
                  $is_sel = in_array((int)$cat['id'], array_map('intval', $sec_cats_selected), true);
                ?>
                  <label class="sec-cat-chip <?= $is_sel ? 'sel' : '' ?>" data-cat-id="<?= $cat['id'] ?>">
                    <input type="checkbox" name="secondary_categories[]" value="<?= $cat['id'] ?>"
                           <?= $is_sel ? 'checked' : '' ?> style="display:none">
                    <?= $cat['parent_id'] ? '↳ ' : '' ?><?= htmlspecialchars($cat['name']) ?>
                  </label>
                <?php endforeach ?>
              </div>
              <div class="hint">Tap categories to add this product to additional categories.</div>
            </div>
            <div class="fg">
              <label class="form-label">🏷️ Tags (comma-separated)</label>
              <input type="text" name="tags_input" class="form-input"
                     value="<?php $tg = json_decode($ep['tags'] ?? '[]', true) ?: []; echo htmlspecialchars(implode(', ', $tg)); ?>"
                     placeholder="e.g. diwali, eco-friendly, corporate gift, bestseller">
              <div class="hint">Short tags shown on product page.</div>
            </div>
            <div class="fg">
              <label class="form-label">🔍 Search Keywords</label>
              <textarea name="keywords_search" class="form-input" rows="3" maxlength="500"
                        placeholder="leather notebook A5 ruled hardcover premium executive diary planner journal"><?= htmlspecialchars($ep['keywords_search'] ?? '') ?></textarea>
              <div class="hint">Comma or space separated. Used for internal search &amp; SEO. Max 500 chars.</div>
            </div>
          </div>

          <!-- =========== MEDIA =========== -->
          <div id="tab-media" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:8px">📸 Product Images &amp; Video</div>

            <div class="guideline">
              <strong>📋 Image Upload Guidelines</strong>
              <ul style="margin:8px 0 0 18px;padding:0">
                <li><strong>Size:</strong> 800 × 800 pixels minimum, square (1:1) aspect ratio</li>
                <li><strong>Format:</strong> JPG, PNG, or WEBP. Max 5 MB per image.</li>
                <li><strong>Background:</strong> Plain white or light grey. No watermarks, no text overlays.</li>
                <li><strong>Lighting:</strong> Even, natural lighting. No harsh shadows.</li>
                <li><strong>Focus:</strong> Product fills 70-80% of frame. Centred, sharp focus.</li>
                <li><strong>Coverage:</strong> Up to 4 images — 1 main + 3 angles (front / side / detail / in-use).</li>
                <li><strong>Branding:</strong> No own logo, packaging text, or third-party brand names.</li>
              </ul>
              <div style="margin-top:8px;font-size:11.5px;color:#78350F">
                Poor-quality images are the #1 reason for product rejection.
              </div>
            </div>

            <div class="slot-grid" id="slotGrid">
              <?php for ($si = 0; $si < 4; $si++): $img = $edit_images[$si] ?? null; ?>
                <?php if ($img): ?>
                  <div class="img-slot filled" data-imgid="<?= $img['id'] ?>" data-prodid="<?= $ep['id'] ?>">
                    <img src="<?= htmlspecialchars(SITE_URL . $img['image_path']) ?>" alt="">
                    <?php if ($img['is_primary']): ?>
                      <div class="slot-lbl">★ PRIMARY</div>
                    <?php else: ?>
                      <div class="slot-lbl" style="background:#64748B;cursor:pointer"
                           data-action="set-primary" data-imgid="<?= $img['id'] ?>" data-prodid="<?= $ep['id'] ?>">Set Primary</div>
                    <?php endif ?>
                    <button type="button" class="slot-x" data-action="delete-img"
                            data-imgid="<?= $img['id'] ?>" data-prodid="<?= $ep['id'] ?>">✕</button>
                  </div>
                <?php else: ?>
                  <div class="slot-empty">
                    <input type="file" name="product_images[]" accept="image/jpeg,image/png,image/webp">
                    <div style="text-align:center;pointer-events:none">
                      <div style="font-size:26px">📷</div>
                      <div style="font-size:10.5px;font-weight:700;color:#94A3B8">
                        Photo <?= $si+1 ?><?= $si === 0 ? ' (Primary)' : '' ?>
                      </div>
                    </div>
                  </div>
                <?php endif ?>
              <?php endfor ?>
            </div>

            <div style="margin-top:14px;padding-top:14px;border-top:1px solid #F0F3F6">
              <label class="form-label">🎬 Product Video URL (YouTube / Vimeo / MP4 link)</label>
              <input type="url" name="video_url" class="form-input"
                     value="<?= htmlspecialchars($ep['video_url'] ?? '') ?>"
                     placeholder="https://www.youtube.com/watch?v=...">
              <div class="hint">Paste a link — do not upload video files. Clients see this on the product page.</div>
            </div>
          </div>

          <!-- =========== CUSTOMISATION =========== -->
          <div id="tab-custom" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:6px">🎨 Customisation Options</div>
            <div style="font-size:12px;color:#64748B;margin-bottom:14px;background:#EEF0FB;border-radius:8px;padding:10px 13px">
              💡 Tell us which print methods work on this product and where the logo can go. This helps clients pick the right customisation.
            </div>
            <input type="hidden" name="printing_input" id="printVal"
                   value="<?= htmlspecialchars(implode(', ', $sel_print)) ?>">
            <input type="hidden" name="placement_input" id="placeVal"
                   value="<?= htmlspecialchars(implode(', ', $sel_place)) ?>">

            <div class="fg">
              <label class="form-label">Printing Methods Supported</label>
              <div class="chip-box" id="printBox">
                <?php foreach ($print_opts as $opt): ?>
                  <span class="mchip <?= in_array($opt, $sel_print) ? 'sel' : '' ?>"
                        data-field="print" data-val="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></span>
                <?php endforeach ?>
                <input type="text" class="chip-inp" id="printInp" placeholder="+ Custom method">
              </div>
              <div class="hint">Click to toggle. Type and press Enter to add a custom method.</div>
            </div>

            <div class="fg">
              <label class="form-label">Logo Placement Zones</label>
              <div class="chip-box" id="placeBox">
                <?php foreach ($place_opts as $opt): ?>
                  <span class="mchip <?= in_array($opt, $sel_place) ? 'sel' : '' ?>"
                        data-field="place" data-val="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></span>
                <?php endforeach ?>
                <input type="text" class="chip-inp" id="placeInp" placeholder="+ Custom zone">
              </div>
              <div class="hint">Where can the client's logo go on this product?</div>
            </div>

            <div class="fg" style="max-width:300px">
              <label class="form-label">AI Recommended Print Method</label>
              <select name="ai_suggest_print" class="form-input">
                <option value="">— None —</option>
                <?php foreach ($ai_opts as $ap): ?>
                  <option value="<?= $ap ?>" <?= ($ep['ai_suggest_print'] ?? '') === $ap ? 'selected' : '' ?>><?= $ap ?></option>
                <?php endforeach ?>
              </select>
              <div class="hint">Suggested as default when client customises.</div>
            </div>
          </div>

          <!-- =========== OCCASIONS =========== -->
          <div id="tab-occasions" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:6px">🎉 Ideal Occasions</div>
            <div style="font-size:12px;color:#64748B;margin-bottom:14px;background:#EEF0FB;border-radius:8px;padding:10px 13px">
              💡 When is this product typically gifted? Helps clients find it for the right occasion.
            </div>
            <input type="hidden" name="ideal_occasions_items" id="occJson"
                   value="<?= htmlspecialchars($ep['ideal_occasions'] ?? '') ?>">
            <div id="occRows">
              <?php foreach ($occ_existing as $oi): ?>
              <div class="occ-row" style="display:grid;grid-template-columns:60px 1fr 140px 34px;gap:8px;align-items:end;margin-bottom:8px;background:#F8FAFC;border:1px solid #E8ECF2;border-radius:9px;padding:10px 13px">
                <div>
                  <label class="form-label">Icon</label>
                  <input type="text" class="form-input or-icon" value="<?= htmlspecialchars($oi['icon'] ?? '') ?>" style="font-size:20px;text-align:center;padding:6px">
                </div>
                <div>
                  <label class="form-label">Occasion</label>
                  <input type="text" class="form-input or-name" value="<?= htmlspecialchars($oi['name'] ?? '') ?>" placeholder="e.g. Diwali Gifting">
                </div>
                <div>
                  <label class="form-label">Season</label>
                  <input type="text" class="form-input or-when" value="<?= htmlspecialchars($oi['when'] ?? '') ?>" placeholder="Oct-Nov">
                </div>
                <div><button type="button" class="rm-btn rm-occ">✕</button></div>
              </div>
              <?php endforeach ?>
            </div>
            <button type="button" class="btn btn-ghost btn-sm" id="addOccBtn">+ Add Occasion</button>
          </div>

          <!-- =========== FAQs =========== -->
          <div id="tab-faqs" class="tab-panel card" style="padding:18px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
              <div>
                <div class="card-title">❓ Product FAQs</div>
                <div style="font-size:11.5px;color:#94A3B8;margin-top:3px">Answer the questions clients commonly ask about this product.</div>
              </div>
              <button type="button" class="btn btn-ghost btn-sm" id="addFaqBtn">+ Add FAQ</button>
            </div>
            <div id="faqList">
              <?php foreach ($edit_faqs as $faq): ?>
              <div class="attr-row">
                <button type="button" class="rm-btn rm-faq" style="position:absolute;top:10px;right:10px">✕</button>
                <div class="fg">
                  <label class="form-label">Question *</label>
                  <input type="text" name="faq_question[]" class="form-input" value="<?= htmlspecialchars($faq['question'] ?? '') ?>" placeholder="e.g. Can I get a sample before bulk order?">
                </div>
                <div>
                  <label class="form-label">Answer *</label>
                  <textarea name="faq_answer[]" class="form-input" rows="2"><?= htmlspecialchars($faq['answer'] ?? '') ?></textarea>
                </div>
              </div>
              <?php endforeach ?>
              <?php if (empty($edit_faqs)): ?>
                <div id="noFaqMsg" style="text-align:center;padding:24px;color:#94A3B8;border:2px dashed #E2E8F0;border-radius:9px">
                  No FAQs yet. Click "+ Add FAQ" to add common Q&amp;A.
                </div>
              <?php endif ?>
            </div>
          </div>

          <!-- =========== SEO =========== -->
          <div id="tab-seo" class="tab-panel card" style="padding:18px">
            <div class="card-title" style="margin-bottom:6px">🔍 SEO Metadata</div>
            <div style="font-size:12px;color:#64748B;margin-bottom:14px;background:#EEF0FB;border-radius:8px;padding:10px 13px">
              💡 Optional. Helps your product rank in search engines. If left empty, Dausto auto-generates from product name.
            </div>
            <div class="fg">
              <label class="form-label">Meta Title <span style="font-weight:400;color:#94A3B8">(max 60 chars)</span></label>
              <input type="text" name="meta_title" class="form-input" maxlength="70"
                     value="<?= htmlspecialchars($ep['meta_title'] ?? '') ?>"
                     placeholder="Premium Leather Diary A5 — Corporate Gift | Dausto">
              <div class="hint" id="mtCount"><?= strlen($ep['meta_title'] ?? '') ?>/60 chars</div>
            </div>
            <div class="fg">
              <label class="form-label">Meta Description <span style="font-weight:400;color:#94A3B8">(max 160 chars)</span></label>
              <textarea name="meta_desc" class="form-input" rows="3" maxlength="200"
                        placeholder="Premium leather diary for corporate gifting. Customisable with your logo. Bulk pricing available."><?= htmlspecialchars($ep['meta_desc'] ?? '') ?></textarea>
              <div class="hint" id="mdCount"><?= strlen($ep['meta_desc'] ?? '') ?>/160 chars</div>
            </div>
          </div>

          <!-- =========== AUDIT (edit only) =========== -->
          <?php if ($is_edit): ?>
          <div id="tab-audit" class="tab-panel card" style="padding:0;overflow:hidden">
            <div style="padding:14px 18px;border-bottom:1px solid #F0F3F6">
              <div class="card-title">📜 Activity History</div>
              <div style="font-size:11.5px;color:#94A3B8;margin-top:3px">Every change to this product is logged. Newest first.</div>
            </div>
            <?php if (empty($edit_audit)): ?>
              <div style="padding:30px;text-align:center;color:#94A3B8;font-size:13px">No activity yet.</div>
            <?php else: ?>
              <div style="max-height:500px;overflow-y:auto">
                <?php foreach ($edit_audit as $a): $fmt = formatAuditAction($a['action']); ?>
                  <div class="audit-row">
                    <div class="audit-tag" style="background:<?= $fmt['bg'] ?>;color:<?= $fmt['color'] ?>"><?= $fmt['label'] ?></div>
                    <div style="flex:1;min-width:0">
                      <?php if (!empty($a['field_changed'])): ?>
                        <div style="font-weight:700;font-size:12.5px">
                          <?= htmlspecialchars($a['field_changed']) ?>:
                          <?php if ($a['old_value'] !== null && $a['old_value'] !== ''): ?>
                            <span style="color:#94A3B8;text-decoration:line-through"><?= htmlspecialchars(mb_strimwidth((string)$a['old_value'], 0, 60, '…')) ?></span> →
                          <?php endif ?>
                          <span style="color:#0F172A"><?= htmlspecialchars(mb_strimwidth((string)$a['new_value'], 0, 60, '…')) ?></span>
                        </div>
                      <?php endif ?>
                      <?php if (!empty($a['notes'])): ?>
                        <div style="font-size:12px;color:#64748B;margin-top:2px"><?= htmlspecialchars($a['notes']) ?></div>
                      <?php endif ?>
                      <div style="font-size:11px;color:#94A3B8;margin-top:3px">
                        <?= istFmt($a['created_at']) ?> · by <?= htmlspecialchars($a['actor_name'] ?? '—') ?> (<?= htmlspecialchars($a['actor_type']) ?>)
                      </div>
                    </div>
                  </div>
                <?php endforeach ?>
              </div>
            <?php endif ?>
          </div>
          <?php endif ?>

        </div>

        <!-- =========== RIGHT SIDEBAR =========== -->
        <div>
          <div class="card" style="padding:14px">
            <button type="submit" name="submit_for_review" value="1" class="btn btn-submit"
                    style="width:100%;justify-content:center;margin-bottom:9px;font-size:14px">
              📤 <?= $is_edit ? 'Resubmit for Review' : 'Submit for Review' ?>
            </button>
            <button type="submit" class="btn btn-primary"
                    style="width:100%;justify-content:center;margin-bottom:9px">
              💾 Save as Draft
            </button>
            <a href="products.php" class="btn btn-ghost"
               style="width:100%;justify-content:center;text-align:center">Cancel</a>
          </div>

          <div class="card" style="padding:13px;font-size:11.5px;line-height:1.65;color:#64748B">
            <div style="color:#0F172A;font-weight:800;font-size:12.5px;margin-bottom:6px">📌 Workflow</div>
            <div style="margin-bottom:4px"><span class="pill status-draft">Draft</span> Private. Not visible to clients.</div>
            <div style="margin-bottom:4px"><span class="pill status-pending">Pending</span> Awaiting Dausto review.</div>
            <div style="margin-bottom:4px"><span class="pill status-active">Active</span> Live on store.</div>
            <div><span class="pill status-rejected">Rejected</span> See feedback &amp; resubmit.</div>
            <div style="margin-top:9px;padding-top:9px;border-top:1px solid #F0F3F6;font-size:11px">
              ℹ️ Edits to Active products go back to Pending for re-approval.
            </div>
          </div>

          <div class="card" style="padding:13px;font-size:11.5px;color:#64748B">
            <div style="color:#0F172A;font-weight:800;font-size:12.5px;margin-bottom:6px">💡 Tips for Approval</div>
            <ul style="margin-left:16px;padding:0;line-height:1.7">
              <li>Fill <strong>all 8 tabs</strong> for fastest approval</li>
              <li>Upload <strong>4 quality images</strong></li>
              <li>Add <strong>FAQs</strong> — saves admin time</li>
              <li>List <strong>print methods</strong> you support</li>
              <li>Submit <strong>realistic bulk tiers</strong></li>
            </ul>
          </div>
        </div>

      </div>
    </form>

    <script>
    (function () {
      // ---- Tabs ----
      var nav = document.getElementById('tabNav');
      var btns = nav ? nav.querySelectorAll('[data-tab]') : [];
      function showTab(id, btn) {
        document.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('show'); });
        btns.forEach(function (b) { b.classList.remove('active'); });
        var p = document.getElementById('tab-' + id);
        if (p) p.classList.add('show');
        if (btn) btn.classList.add('active');
      }
      if (btns.length) showTab(btns[0].getAttribute('data-tab'), btns[0]);
      if (nav) nav.addEventListener('click', function (e) {
        var b = e.target.closest('[data-tab]');
        if (b) showTab(b.getAttribute('data-tab'), b);
      });

      // ---- Secondary category chips ----
      var secBox = document.getElementById('secCatBox');
      if (secBox) {
        secBox.addEventListener('click', function (e) {
          var chip = e.target.closest('.sec-cat-chip');
          if (!chip) return;
          e.preventDefault();
          var cb = chip.querySelector('input[type=checkbox]');
          if (!cb) return;
          cb.checked = !cb.checked;
          chip.classList.toggle('sel', cb.checked);
          var primary = document.getElementById('primaryCat');
          if (primary && cb.checked && cb.value === primary.value) {
            cb.checked = false; chip.classList.remove('sel');
            alert('This is already your primary category.');
          }
        });
      }

      // ---- Image grid ----
      var grid = document.getElementById('slotGrid');
      if (grid) {
        grid.addEventListener('change', function (e) {
          if (!e.target.matches('input[type=file]')) return;
          var inp = e.target, slot = inp.closest('.slot-empty');
          if (!slot || !inp.files || !inp.files[0]) return;
          var file = inp.files[0];
          if (file.size > 5 * 1024 * 1024) { alert('Image too large. Max 5MB.'); inp.value = ''; return; }
          var r = new FileReader();
          r.onload = function (ev) {
            slot.style.background = 'url(' + ev.target.result + ') center/cover no-repeat';
            slot.querySelector('div').style.opacity = '0.3';
          };
          r.readAsDataURL(file);
        });
        grid.addEventListener('click', function (e) {
          var el = e.target.closest('[data-action]');
          if (!el) return;
          var act = el.getAttribute('data-action'),
              iid = el.getAttribute('data-imgid'),
              pid = el.getAttribute('data-prodid');
          if (act === 'delete-img') {
            if (!confirm('Delete this image?')) return;
            fetch('products.php?img_action=delete&img_id=' + iid + '&prod_id=' + pid)
              .then(function (r) { return r.json(); })
              .then(function (d) { if (d && d.ok) { var s = el.closest('.img-slot'); if (s) s.remove(); } });
          }
          if (act === 'set-primary') {
            fetch('products.php?img_action=set_primary&img_id=' + iid + '&prod_id=' + pid)
              .then(function (r) { return r.json(); })
              .then(function (d) { if (d && d.ok) location.reload(); });
          }
        });
      }

      // ---- Bulk tiers ----
      function attachTier(row) {
        var rm = row.querySelector('.rm-tier');
        if (rm) rm.addEventListener('click', function () { row.remove(); });
      }
      document.querySelectorAll('#tierList .tier-row').forEach(attachTier);
      var addTierBtn = document.getElementById('addTierBtn');
      if (addTierBtn) addTierBtn.addEventListener('click', function () {
        var no = document.getElementById('noTierMsg'); if (no) no.remove();
        var rows = document.querySelectorAll('#tierList .tier-row');
        var moq = parseInt(document.getElementById('moqInp') && document.getElementById('moqInp').value) || 10;
        var start = moq;
        if (rows.length) {
          var lastTo = rows[rows.length - 1].querySelectorAll('input')[1].value;
          if (lastTo) start = parseInt(lastTo) + 1;
        }
        var row = document.createElement('div');
        row.className = 'tier-row';
        row.style.cssText = 'display:grid;grid-template-columns:80px 80px 130px 150px 34px;gap:8px;margin-bottom:7px';
        row.innerHTML =
          '<input type="number" name="tier_min[]" class="form-input" value="' + start + '" min="1" style="padding:7px">'
          + '<input type="number" name="tier_max[]" class="form-input" min="0" placeholder="∞" style="padding:7px">'
          + '<input type="number" name="tier_price[]" class="form-input" min="0" step="0.01" style="padding:7px">'
          + '<select name="tier_label[]" class="form-input" style="padding:7px">'
          + '<option value="">—</option><option>Trial / Sample</option><option>Small Team</option><option>Department</option><option>CSR Budget</option><option>Enterprise</option></select>'
          + '<button type="button" class="rm-btn rm-tier">✕</button>';
        document.getElementById('tierList').appendChild(row);
        attachTier(row);
      });

      // ---- Variants ----
      function attachVar(row) {
        var rm = row.querySelector('.rm-var');
        if (rm) rm.addEventListener('click', function () { row.remove(); });
      }
      document.querySelectorAll('#varList .var-row').forEach(attachVar);
      var addVarBtn = document.getElementById('addVarBtn');
      if (addVarBtn) addVarBtn.addEventListener('click', function () {
        var row = document.createElement('div');
        row.className = 'var-row';
        row.style.cssText = 'display:grid;grid-template-columns:1fr 130px 34px;gap:8px;margin-bottom:7px';
        row.innerHTML =
          '<input type="text" name="variant_val[]" class="form-input" placeholder="e.g. M, Red">'
          + '<input type="number" name="variant_qty[]" class="form-input" value="0" min="0" style="text-align:center">'
          + '<button type="button" class="rm-btn rm-var">✕</button>';
        document.getElementById('varList').appendChild(row);
        attachVar(row);
      });

      // ---- Customisation chips ----
      var fieldMap = { 'print': 'printVal', 'place': 'placeVal' };
      function updateChipHidden(field) {
        var sel = [];
        document.querySelectorAll('.mchip[data-field="' + field + '"].sel').forEach(function (c) {
          sel.push(c.getAttribute('data-val'));
        });
        var h = document.getElementById(fieldMap[field]);
        if (h) h.value = sel.join(', ');
      }
      function attachChip(c) {
        c.addEventListener('click', function () {
          c.classList.toggle('sel');
          updateChipHidden(c.getAttribute('data-field'));
        });
      }
      document.querySelectorAll('#printBox .mchip, #placeBox .mchip').forEach(attachChip);
      [['printInp', 'printBox', 'print'], ['placeInp', 'placeBox', 'place']].forEach(function (cfg) {
        var inp = document.getElementById(cfg[0]), box = document.getElementById(cfg[1]), f = cfg[2];
        if (!inp || !box) return;
        inp.addEventListener('keydown', function (e) {
          if (e.key !== 'Enter') return;
          e.preventDefault();
          var v = inp.value.trim(); if (!v) return;
          var ex = false;
          box.querySelectorAll('.mchip').forEach(function (c) {
            if (c.getAttribute('data-val').toLowerCase() === v.toLowerCase()) { c.classList.add('sel'); ex = true; }
          });
          if (!ex) {
            var nc = document.createElement('span');
            nc.className = 'mchip sel';
            nc.setAttribute('data-field', f);
            nc.setAttribute('data-val', v);
            nc.textContent = v;
            attachChip(nc);
            box.insertBefore(nc, inp);
          }
          inp.value = '';
          updateChipHidden(f);
        });
      });

      // ---- Occasions ----
      function syncOcc() {
        var arr = [];
        document.querySelectorAll('#occRows .occ-row').forEach(function (r) {
          arr.push({
            icon: r.querySelector('.or-icon').value,
            name: r.querySelector('.or-name').value,
            when: r.querySelector('.or-when').value
          });
        });
        document.getElementById('occJson').value = JSON.stringify(arr);
      }
      function attachOcc(row) {
        row.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', syncOcc); });
        var rm = row.querySelector('.rm-occ');
        if (rm) rm.addEventListener('click', function () { row.remove(); syncOcc(); });
      }
      document.querySelectorAll('#occRows .occ-row').forEach(attachOcc);
      var addOccBtn = document.getElementById('addOccBtn');
      if (addOccBtn) addOccBtn.addEventListener('click', function () {
        var row = document.createElement('div');
        row.className = 'occ-row';
        row.style.cssText = 'display:grid;grid-template-columns:60px 1fr 140px 34px;gap:8px;align-items:end;margin-bottom:8px;background:#F8FAFC;border:1px solid #E8ECF2;border-radius:9px;padding:10px 13px';
        row.innerHTML =
          '<div><label class="form-label">Icon</label><input type="text" class="form-input or-icon" style="font-size:20px;text-align:center;padding:6px" placeholder="🎁"></div>'
          + '<div><label class="form-label">Occasion</label><input type="text" class="form-input or-name"></div>'
          + '<div><label class="form-label">Season</label><input type="text" class="form-input or-when" placeholder="Year-round"></div>'
          + '<div><button type="button" class="rm-btn rm-occ">✕</button></div>';
        document.getElementById('occRows').appendChild(row);
        attachOcc(row);
        syncOcc();
      });
      syncOcc();

      // ---- FAQs ----
      function attachFaq(row) {
        var rm = row.querySelector('.rm-faq, .rm-btn');
        if (rm) rm.addEventListener('click', function () { row.remove(); });
      }
      document.querySelectorAll('#faqList .attr-row').forEach(attachFaq);
      var addFaqBtn = document.getElementById('addFaqBtn');
      if (addFaqBtn) addFaqBtn.addEventListener('click', function () {
        var no = document.getElementById('noFaqMsg'); if (no) no.remove();
        var row = document.createElement('div');
        row.className = 'attr-row';
        row.innerHTML =
          '<button type="button" class="rm-btn rm-faq" style="position:absolute;top:10px;right:10px">✕</button>'
          + '<div class="fg"><label class="form-label">Question *</label><input type="text" name="faq_question[]" class="form-input" placeholder="e.g. Can I get a sample first?"></div>'
          + '<div><label class="form-label">Answer *</label><textarea name="faq_answer[]" class="form-input" rows="2"></textarea></div>';
        document.getElementById('faqList').appendChild(row);
        attachFaq(row);
      });

      // ---- SEO char counters ----
      var mt = document.querySelector('[name="meta_title"]'), mtc = document.getElementById('mtCount');
      if (mt && mtc) mt.addEventListener('input', function () {
        mtc.textContent = mt.value.length + '/60 chars';
        mtc.style.color = mt.value.length > 60 ? '#DC2626' : '#94A3B8';
      });
      var md = document.querySelector('[name="meta_desc"]'), mdc = document.getElementById('mdCount');
      if (md && mdc) md.addEventListener('input', function () {
        mdc.textContent = md.value.length + '/160 chars';
        mdc.style.color = md.value.length > 160 ? '#DC2626' : '#94A3B8';
      });
    })();
    </script>

<?php endif ?>

  </div>
</main>
</body>
</html>
