<?php
// ============================================================
// FILE PATH ON HOSTINGER: public_html/vendor/login.php
// VENDOR PORTAL LOGIN
// ============================================================
ob_start();
$configs=[
    '/home/u624259711/domains/orchid-alligator-169347.hostingersite.com/public_html/config.php',
    dirname(__DIR__).'/config.php',
];
foreach($configs as $c){if(file_exists($c)){require_once $c;break;}}
if(!defined('PUBLIC_PATH')) die('<p style="color:red;font-family:sans-serif;padding:40px">config.php not found</p>');

if(session_status()===PHP_SESSION_NONE){
    session_start([
        'cookie_httponly'=>true,
        'cookie_secure'=>isset($_SERVER['HTTPS']),
        'cookie_samesite'=>'Lax',
        'use_strict_mode'=>true,
    ]);
}

// Already logged in as vendor
if(!empty($_SESSION['user_id'])&&($_SESSION['portal']??'')==='vendor'){
    session_write_close(); ob_end_clean();
    header('Location: '.VENDOR_URL.'/index.php'); exit;
}

$error=''; $email_val='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $email    = strtolower(trim($_POST['email']??''));
    $password = $_POST['password']??'';
    $email_val= htmlspecialchars($email);

    if(empty($email)||empty($password)){
        $error='Please enter your email and password.';
    } else {
        try {
            $dsn='mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4';
            $pdo=new PDO($dsn,DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
            $stmt=$pdo->prepare("SELECT id,name,email,password_hash,role,portal,permissions,status FROM users WHERE email=? LIMIT 1");
            $stmt->execute([$email]); $user=$stmt->fetch();

            if(!$user){
                password_verify('dummy','$2y$12$invalid0000000000000000000000000000000000000000000000');
                $error='Invalid email or password.';
            } elseif($user['status']!=='active'){
                $error='Your account is not active. Contact Dausto support.';
            } elseif($user['portal']!=='vendor'){
                $error='This account is not a vendor account. <a href="'.SITE_URL.'/login.php" style="color:#E8A020;font-weight:700">Client Login →</a>';
            } elseif(!password_verify($password,$user['password_hash'])){
                $error='Invalid email or password.';
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id']    =$user['id'];
                $_SESSION['name']       =$user['name'];
                $_SESSION['email']      =$user['email'];
                $_SESSION['role']       =$user['role'];
                $_SESSION['portal']     ='vendor';
                $_SESSION['permissions']=json_decode($user['permissions']??'[]',true)??[];
                $pdo->prepare("UPDATE users SET last_login=NOW() WHERE id=?")->execute([$user['id']]);
                session_write_close(); ob_end_clean();
                header('Location: '.VENDOR_URL.'/index.php'); exit;
            }
        } catch(PDOException $e){
            error_log('Vendor login: '.$e->getMessage());
            $error='System error. Please try again.';
        }
    }
}

if(empty($_SESSION['csrf_token'])) $_SESSION['csrf_token']=bin2hex(random_bytes(32));
ob_end_flush();
?>

<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Vendor Login — Dausto</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

body{
font-family:‘DM Sans’,sans-serif;
min-height:100vh;
display:flex;
align-items:center;
justify-content:center;
padding:20px;
background:#0E1A4A;
position:relative;
overflow:hidden;
}

/* Decorative background blobs */
body::before{
content:’’;
position:fixed;
top:-120px;right:-120px;
width:480px;height:480px;
background:radial-gradient(circle,rgba(46,61,154,0.55) 0%,transparent 70%);
border-radius:50%;
pointer-events:none;
}
body::after{
content:’’;
position:fixed;
bottom:-100px;left:-80px;
width:360px;height:360px;
background:radial-gradient(circle,rgba(232,160,32,0.12) 0%,transparent 70%);
border-radius:50%;
pointer-events:none;
}

/* Subtle grid pattern on bg */
.bg-grid{
position:fixed;inset:0;pointer-events:none;
background-image:linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),
linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px);
background-size:40px 40px;
}

.card{
background:#fff;
border-radius:20px;
box-shadow:0 8px 16px rgba(0,0,0,0.15),0 32px 80px rgba(0,0,0,0.25);
width:100%;max-width:420px;
padding:40px 38px;
position:relative;
z-index:2;
}

/* ── LOGO AREA ── */
.logo-area{
display:flex;align-items:center;gap:12px;
margin-bottom:28px;
padding-bottom:24px;
border-bottom:1px solid #EEF0F7;
}
.logo-img-wrap{
height:44px;
display:flex;align-items:center;
}
.logo-img-wrap img{
height:44px;
width:auto;
display:block;
/* Ensures crisp render even if PNG has transparent bg */
object-fit:contain;
}
.vendor-badge{
margin-left:auto;
background:#EEF0F7;
color:#1E2F7A;
padding:4px 12px;
border-radius:20px;
font-size:11px;
font-weight:700;
letter-spacing:0.5px;
border:1px solid #C8CEED;
white-space:nowrap;
}

/* ── HEADING ── */
.login-heading{
font-family:‘DM Serif Display’,serif;
font-size:28px;
color:#141F52;
line-height:1.15;
margin-bottom:6px;
}
.login-sub{
font-size:13.5px;
color:#6B7280;
margin-bottom:26px;
line-height:1.5;
}

/* ── ERROR ── */
.alert-err{
background:#FEF2F2;
border:1px solid #FECACA;
border-left:3px solid #DC2626;
border-radius:9px;
padding:11px 14px;
font-size:13px;
color:#7F1D1D;
display:flex;
align-items:flex-start;
gap:8px;
margin-bottom:20px;
}

/* ── FORM ── */
.fl{
display:block;
font-size:11.5px;
font-weight:700;
color:#374151;
letter-spacing:.06em;
text-transform:uppercase;
margin-bottom:6px;
}
.input-wrap{position:relative}
.fi{
width:100%;
border:1.5px solid #DDE1EE;
border-radius:10px;
padding:12px 14px 12px 42px;
font-size:14px;
color:#0F172A;
font-family:‘DM Sans’,sans-serif;
outline:none;
background:#F8F9FC;
transition:all .15s;
}
.fi:focus{
border-color:#2E3D9A;
box-shadow:0 0 0 3px rgba(46,61,154,0.12);
background:#fff;
}
.fi-icon{
position:absolute;left:14px;top:50%;
transform:translateY(-50%);
color:#9CA3AF;pointer-events:none;
}
.eye-btn{
position:absolute;right:14px;top:50%;
transform:translateY(-50%);
background:none;border:none;
color:#9CA3AF;cursor:pointer;
padding:0;display:flex;
transition:color .15s;
}
.eye-btn:hover{color:#2E3D9A;}

/* ── SUBMIT ── */
.btn-login{
width:100%;padding:14px;
background:linear-gradient(135deg,#1E2F7A 0%,#2E3D9A 100%);
color:#fff;
font-size:15px;font-weight:700;
font-family:‘DM Sans’,sans-serif;
border:none;border-radius:10px;
cursor:pointer;
box-shadow:0 4px 16px rgba(30,47,122,0.35);
transition:all .18s;
display:flex;align-items:center;justify-content:center;gap:8px;
letter-spacing:0.2px;
}
.btn-login:hover{
transform:translateY(-1px);
box-shadow:0 8px 24px rgba(30,47,122,0.45);
background:linear-gradient(135deg,#141F52 0%,#1E2F7A 100%);
}
.btn-login:disabled{
opacity:0.7;cursor:not-allowed;transform:none;
}

/* ── FORGOT + FOOTER ── */
.forgot-link{
font-size:12.5px;color:#2E3D9A;
font-weight:600;text-decoration:none;
}
.forgot-link:hover{text-decoration:underline;}

.footer-links{
margin-top:22px;
text-align:center;
font-size:12px;
color:#9CA3AF;
padding-top:18px;
border-top:1px solid #EEF0F7;
}
.footer-links a{
color:#9CA3AF;text-decoration:none;
transition:color .15s;
}
.footer-links a:hover{color:#2E3D9A;}

/* ── GOLD ACCENT LINE AT TOP OF CARD ── */
.card::before{
content:’’;
position:absolute;
top:0;left:24px;right:24px;height:3px;
background:linear-gradient(90deg,#E8A020,#F5C355,#E8A020);
border-radius:0 0 4px 4px;
}
</style>

</head>
<body>
<div class="bg-grid"></div>

<div class="card">

  <!-- LOGO -->

  <div class="logo-area">
    <div class="logo-img-wrap">
      <!--
        dausto.png is in public_html/
        This file is in public_html/vendor/
        So path is ../dausto.png
        If you use SITE_URL constant: <?= SITE_URL ?>/dausto.png also works
      -->
      <img src="../dausto.png" alt="Dausto Corporate Gifts">
    </div>
    <span class="vendor-badge">🏪 Vendor Portal</span>
  </div>

  <!-- HEADING -->

  <h1 class="login-heading">Welcome back</h1>
  <p class="login-sub">Sign in to your Dausto Vendor account to manage orders, samples, and products.</p>

  <!-- ERROR -->

  <?php if($error): ?>

  <div class="alert-err">
    <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" style="flex-shrink:0;margin-top:1px">
      <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
    </svg>
    <span><?=$error?></span>
  </div>
  <?php endif ?>

  <!-- FORM -->

  <form method="POST" id="loginForm">
    <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">


<div style="margin-bottom:16px">
  <label class="fl" for="email">Email Address</label>
  <div class="input-wrap">
    <span class="fi-icon">
      <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
        <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"/>
        <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"/>
      </svg>
    </span>
    <input type="email" id="email" name="email" class="fi"
           placeholder="vendor@company.com"
           value="<?=$email_val?>"
           autocomplete="email" required>
  </div>
</div>

<div style="margin-bottom:24px">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
    <label class="fl" for="pwd" style="margin-bottom:0">Password</label>
    <a href="#" class="forgot-link"
       onclick="alert('Contact Dausto support:\nWhatsApp: +91 93193 00883');return false">
      Forgot password?
    </a>
  </div>
  <div class="input-wrap">
    <span class="fi-icon">
      <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
        <path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"/>
      </svg>
    </span>
    <input type="password" id="pwd" name="password" class="fi"
           placeholder="Enter your password"
           autocomplete="current-password" required
           style="padding-right:44px">
    <button type="button" class="eye-btn"
            onclick="var p=document.getElementById('pwd');p.type=p.type==='password'?'text':'password'">
      <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 12a2 2 0 100-4 2 2 0 000 4z"/>
        <path fill-rule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clip-rule="evenodd"/>
      </svg>
    </button>
  </div>
</div>

<button type="submit" class="btn-login" id="submitBtn">
  Sign In
  <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor">
    <path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
  </svg>
</button>


  </form>

  <!-- FOOTER LINKS -->

  <div class="footer-links">
    
    <a href="https://wa.me/919319300883">💬 Support</a>
  </div>

</div>

<script>
document.getElementById('loginForm').addEventListener('submit', function(){
    var b = document.getElementById('submitBtn');
    b.disabled = true;
    b.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="animation:spin .7s linear infinite"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/></svg> Signing in...';
    setTimeout(function(){ b.disabled=false; b.innerHTML='Sign In <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clip-rule="evenodd"/></svg>'; }, 10000);
});

document.addEventListener('DOMContentLoaded', function(){
    var e = document.getElementById('email');
    if(e && !e.value) e.focus();
    else document.getElementById('pwd').focus();
});
</script>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

</body>
</html>